#include<iostream>
#include<string>
#include"generalplayer.h"
using namespace std;
#ifndef absmon_h
#define absmon_h
class gp;
class absmon 
{
public:
	string serial()const;
	void unserial()const;
	absmon(string, int, int, int, int, int,int);
	~absmon();
	void attr();
	virtual void attackto(gp*)=0;
	void sethp(int);
	int gethp()const;
	void setmp(int);
	int getmp()const;
	int  getdef()const;
	static int count;
	string name;
   void unserial();
	const int attack;
	const int defense;
	const int exp;
	const int max_hp;
	const int max_mp;
	const int money;//������o����
private:
	int hp;
	int mp;
};
#endif
