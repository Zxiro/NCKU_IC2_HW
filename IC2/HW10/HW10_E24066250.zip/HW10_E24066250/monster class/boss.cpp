#include<iostream>
#include<string>
#include"generalplayer.h"
#include"boss.h"
#include<time.h>
#include"goblin.h"
#include"zombie.h"
using namespace std;

boss::boss()
	:absmon("JWHuang",120,100,42,250,100,125)
{
	sethp(max_hp); setmp(max_mp);
}
boss::~boss()
{
	count--;
}
void boss::attackto(gp*p) 
{if(gethp()<max_hp)
	sethp(gethp()*1.1);
if (getmp() < max_mp)
	setmp(getmp()*1.05);

srand(time(NULL));
int dam;
int a = (rand() % 3), b = (rand() % 2);
switch (a)
{
case(0):
	switch (b)
	{
	case(0):
		dam = (attack - p->getDefense())*1.1;
		cout << attack << "Mon ATT" << endl;
		cout << endl << endl;
		cout << p->getDefense() << "Player DEF" << endl;
		cout << endl << endl;
		cout << dam << endl << "1.1��" << endl;
		cout << endl << endl;
		break;
	case(1):
		dam = (attack - p->getDefense())*0.9;
		cout << attack << "Mon ATT" << endl;
		cout << endl << endl;
		cout << p->getDefense() << "Player DEF" << endl;
		cout << endl << endl;
		cout << dam << endl << "0.9��" << endl;
		cout << endl << endl;
		break;
	case(2):
		dam = (attack - p->getDefense());
		cout << attack << "Mon ATT" << endl;
		cout << endl << endl;
		cout << p->getDefense() << "Player DEF"<< endl;
		cout << endl << endl;
		cout << dam << endl << "1��" << endl;
		cout << endl << endl;
		break;
	}
	break;
case(1):
	dam = (attack * 4 - p->getDefense());
	cout << attack << "Mon ATT" << endl;
	cout << endl << endl;
	cout << p->getDefense() << "Player DEF" << endl;
	cout << endl << endl;
	cout << dam << endl << "4��" << endl;
	cout << endl << endl;
	setmp(getmp() - 10);
	break;
}
if(dam>=0)
p->setHP(p->getHP() - dam);
}
/*int main() 
{
	boss();
	goblin();
	zombie();
	system("pause");
}*/