#include<iostream>
#include <math.h>
#include<string>
#include"generalplayer.h"
#include"orc.h"
using namespace std;
orc::orc() 
{
	setAttr(1);
	setHP(200);
	setMP(30);
	setExp(0);
	setName("anonymous");
};
orc::orc(int a)
{
	setLevel(a);
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setName("anonymous");
	setExp(pow(10, log2(a - 1 + 1)));
}
orc::orc(int a, string b) 
{
	setName(b);
	setLevel(a);
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setExp(pow(10, log2(a - 1 + 1)));
};
orc::orc(const orc & f) 
{
	setLevel(f.level);
	setHP(f.getHP());
	setMP(f.getMP());
	setExp(f.getExp());
	setAttr(f.level);
	setName(f.getName());
};
void orc::levelUp(void) 
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
	cout << level << endl;

}
void orc::setAttr(int a) 
{
	if (a > 0)
	{
		max_hp = 200+ 20 * a;
		max_mp = 30 + 5 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 50 + 12 * a;
		defense = 30 + 10 * a;
		//cout << "max_hp:" << max_hp << "  " << "max_mp:" << max_mp << "  " << "max_exp:" << max_exp << "  " << "attack:" << attack << "  " << "defense:" << defense << "  " << endl;
	}
}
void orc::setLevel(int a)
{
	if (a > 0)
	{
		level = a;
		setAttr(a);
	}
	else if (a <= 0) { level = 1; setAttr(1);
	}
}
void orc::increaseExp(int a)
{
	setExp(getExp() + a);
	if (getExp() >= max_exp)
	{
		while (true)
		{
			if (getExp() >= max_exp)
				levelUp();
			else
				break;
		}
	}
}