﻿#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<sstream>
#include<iomanip>
#include"maze.h"
#include<conio.h>
using namespace std;
int maze::getpost_x()
{
	return post_x;
}
int maze::getpost_y() 
{
	return post_y;
}
maze::maze()
{
	fstream file;
	string line, in;
    cout << "plz enter the maze:";
	cin >> in;
	in = in + ".txt";
	file.open(in, ios::in);
	if (!file)
	{
		cout << "Unable to read the file Plz check!!" << endl;
	}
	stringstream ss;//另一個儲存資料的地方
	while (getline(file, line))//抓字串string
	{
		vector <int> temp;
		ss << line;
		string route;
		while (getline(ss, route, ','))//迴避逗號
		{
			stringstream strtoint;
			int num;
			strtoint << route; strtoint >> num;
			temp.push_back(num);
		}
		okr.push_back(temp);
		ss.str("");
		ss.clear();
	}
	for (int i = 0; i < okr.size(); i++)//做出data//i=row
	{
		vector<int>tempa;
		for (int k = 0; k < okr[i].size(); k++)//k=col
		{
			tempa.push_back(0);
		}
	data.push_back(tempa);
	chd.push_back(tempa);
	}
	for (int i = 0; i < okr.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < okr[i].size(); k++)//k=col
		{
			if (okr[i][k] == 200)
			{
				data[i][k] = 1;//玩家所在計1
				post_x = k;
				post_y = i;
				okr[i][k] = 0;
			}
			else continue;
		}
	}
	print();
}
void maze::print() 
{
	for (int i = 1; i < okr.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < okr[i].size(); k++)//k=colk=x
		{
			if (i == post_y && k == post_x)
			{
				data[i][k] = 1;
				for (int n = -2; n < 3; n++)
				{
					for (int p = -2; p < 3; p++)
					{
						if (n == 0 && p == 0) { continue; }
						if (post_y + n < 1 || post_y + n > okr.size() - 1 || post_x + p > okr[post_y].size() - 1 || post_x + p < 0)
						{
							continue;
						}
						else if (0 < post_y + n <= okr.size() - 1 && -1 < post_x + p <= okr[post_y].size() - 1)
						{
							if (okr[post_y + n][post_x + p] == 0) 
							{
								data[post_y + n][post_x + p] = 3;//roads
							}
							else if (okr[post_y + n][post_x + p] == 1)
							{
								data[post_y + n][post_x + p] = 4;//walls
							}
						}
					}
					continue;
				}
			}
		}
	}
	for (int i = 1; i < okr.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < okr[i].size(); k++)//k=colk=x
		{
			if (data[i][k] == 1) { cout << setw(2) << "P"; }
			else if (data[i][k] == 3) { cout << setw(2) << "口"; }
			else if (data[i][k] == 4) { cout << setw(2) << "■"; }
			else cout << setw(2) << "";
		}
		cout << endl;
	}
	for (int i = 1; i < okr.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < okr[i].size(); k++)//k=colk=x
		{
			data[i][k] = 0;
		}
	}
}
void maze::move() 
{
	while (true)
	{
		cout << "選擇行走的方向" << endl;
		unsigned char key = _getch();//輸入的值
		if (key != 'w' && key != 'a' && key != 's' && key != 'd')
		{
			cout << "Wrong Way" << endl;
			continue;
		}
		switch (key)
		{
		case('w'):
		{if (okr[post_y - 1][post_x]!= 1)
		{
			system("cls");
			post_y=post_y - 1;
		    print();
			cout << "Player_postion:(" << post_x << "," << post_y << ")" << endl;
			break;
		}
		cout << "wrong way" << endl;
		break;
		}
		case('a'):
		{if (okr[post_y ][post_x-1] != 1) {
			system("cls");
			post_x=post_x - 1;
			print();
			cout << "Player_postion:(" << post_x << "," << post_y << ")" << endl;
			break;
		}
			cout << "wrong way" << endl;
			break;
		}

		case('s'):
		{if (okr[post_y+1][post_x ] != 1) 
		{
			system("cls");
			post_y=post_y + 1;
			print();
			cout << "Player_postion:(" << post_x << "," << post_y << ")" << endl;
			break;
		}
			cout << "wrong way" << endl;
			break;
		}
		case('d'):
		{if (okr[post_y ][post_x+1] != 1) {
			system("cls");
			post_x=post_x + 1;
			print();
			cout << "Player_postion:(" << post_x << "," << post_y << ")" << endl;
			break;
		}
			cout << "wrong way" << endl;
			break;
		}
		}
	}
}
