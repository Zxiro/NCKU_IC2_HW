#include<iostream>
#include<math.h>
#include"generalplayer.h"
using namespace std;
#ifndef knight_h
#define knight_h
class knight :public gp
{
public:
	knight();
	knight(int);
	knight(int, string);
	knight(const knight&);
	void setLevel(int);
	void setAttr(int);
	void levelUp(void);
	void heal(void);
	void increaseExp(int);
};
#endif
