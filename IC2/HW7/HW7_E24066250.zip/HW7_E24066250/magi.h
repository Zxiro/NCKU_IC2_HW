#include<iostream>
#include<math.h>
#include"generalplayer.h"
using namespace std;
#ifndef magi_h
#define magi_h
class magi :public gp
{
public:
	magi();
	magi(int);
	magi(int, string);
	magi(const magi&);
	void setLevel(int);
	void setAttr(int);
	void levelUp(void);
	void pray(void);
	void increaseExp(int);
};
#endif once
