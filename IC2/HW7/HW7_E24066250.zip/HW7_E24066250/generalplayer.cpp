#include<iostream>
#include <math.h>
#include"generalplayer.h"
using namespace std;
gp::gp()//default
{
	level = 1;
	setHP(100);
	setMP(50);
	setExp(0);
	setName("anonymous");
}
gp::gp(int a) //without name
{
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setName("anonymous");
	setExp(pow(10, log2(a - 1 + 1)));
}
gp::gp(int a,string e)//with name
{
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setExp(pow(10, log2(a - 1 + 1)));
	setName("anonymous");
}
gp::gp(const gp&f) //copy
{
	setLevel(f.level);
	setHP(f.getHP());
	setMP(f.getMP());
	setExp(f.getExp());
	setAttr(f.level);
	setName(f.name);
}
string gp::getName()const //getname
{
	return name;
}
int gp::getAttack(void) const
{
	return attack;
}
int gp::getDefense(void) const
{
	return defense;
}
int gp::getMaxHP(void) const
{
	return max_hp;
}
int gp::getMaxMP(void) const
{
	return max_mp;
}
int gp::getmaxexp(void) const
{
	return max_exp;
}
int gp::getHP()const
{
	return hp;
}
int gp::getExp()const
{
	return exp;
}
int gp::getMP()const
{
	return mp;
}
void gp::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void gp::setName(string a) 
{
	name = a;
}
void gp::setHP(int a) 
{
	hp = a;
}
void gp::setMP(int a) 
{
	mp = a;
}
void gp::setExp(int a) 
{
	exp = a;
}
void gp::setLevel(int a) 
{
	if (a > 0) 
	{
		level = a;
		setAttr(a);
		cout << level;
	}
	else if (a <= 0) {
		level = 1; setAttr(1);
		cout << level;
	}
}
void gp::setAttr(int a) 
{
	if (a > 0)
	{
		max_hp = 100 + 10 * a;
		max_mp = 40 + 5 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 20 + 5 * a;
		defense = 20 + 5 * a;
	}
}
void gp::increaseHP(int a)
{
	if (hp + a > max_hp) { hp = max_hp; }
	else hp = hp + a;
}
void gp::increaseMP(int a) 
{
	if (mp + a > max_mp) { mp = max_mp; }
	else mp = mp + a;
}
void gp::increaseExp(int a)
{
	exp = exp + a;
	if (exp >= max_exp) 
	{
		while (true)
		{
			if(exp>=max_exp)
			levelUp();
		else 
			break;
		}
	}
}
void gp::recoverHP(void) 
{
	hp = max_hp;
}
void gp::recoverMP(void)
{	
	mp = max_mp;
} 


