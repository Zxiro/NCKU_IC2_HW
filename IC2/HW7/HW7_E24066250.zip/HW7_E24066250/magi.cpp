#include<iostream>
#include<math.h>
#include"generalplayer.h"
#include"magi.h"
using namespace std;
magi::magi()
{
	setLevel(1);
	setHP(100);
	setMP(120);
	setExp(0);
	setName("anonymous");
};
magi::magi(int a)
{
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setName("anonymous");
	setExp(pow(10, log2(a - 1 + 1)));
};
magi::magi(int a, string b)
{
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setExp(pow(10, log2(a - 1 + 1)));
	setName("anonymous");
};
magi::magi(const magi &f)
{
	setLevel(f.level);
	setHP(f.getHP());
	setMP(f.getMP());
	setExp(f.getExp());
	setAttr(f.level);
	setName(f.getName());
};
void magi::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void magi::setAttr(int a)
{
	if (a > 0)
	{
		max_hp = 120 + 20 * a;
		max_mp = 100 + 7 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 30 + 8 * a;
		defense = 25 + 7 * a;
	}
}
void magi::setLevel(int a)
{
	if (a > 0)
	{
		level = a;
		setAttr(a);
	}
	else if (a <= 0) {
		level = 1; setAttr(1);
		cout << level;
	}
}
void magi::increaseExp(int a)
{
	setExp(getExp() + a);
	if (getExp() >= max_exp)
	{
		while (true)
		{
			if (getExp() >= max_exp)
				levelUp();
			else
				break;
		}
	}
}
void magi::pray() 
{
	int h = getHP();
	int m = getMP();
	if (h - level * 5 > 0) 
	{
		h=h - level * 5;
		m=m + level * 10;
		if (m + level * 10 >= max_mp  )
		{
			setMP(max_mp);
		}
	}
	cout << "slepp" << endl;
}
