#include<iostream>
using namespace std;
#ifndef generalplayer_h
#define generalplayer_h
class gp
{
public:
	gp();
	gp(int);
	gp(int,string);//constructor with player name
	gp(const gp &); //copy constructor
	string getName()const;
	void setName(string);
	int getHP()const;
	void setHP(int);
	int getMP()const;
	void setMP(int);
	int getExp()const;
	void setExp(int);
	void setLevel(int);
	void setAttr(int);
	void levelUp(void);
	void increaseHP(int);
	void increaseMP(int);
	void increaseExp(int);
	void recoverHP(void); // hp = max_hp;
	void recoverMP(void); // mp = max_mp;
	int getAttack(void) const;
	int getDefense(void) const;
	int getMaxHP(void) const;
	int getMaxMP(void) const;
	int getmaxexp(void) const;
private:
	string name;
	int hp ; // >=0   <max
	int mp; // >=0  <max
	int exp;// >=0  <max
protected:
	int level; // >=0
	int max_hp; // automatically calculated, >=0
	int max_mp;// automatically calculated, >=0
	int max_exp;// automatically calculated, >=0
	int attack;// automatically calculated, >=0
	int defense; // automatically calculated, >=0

};
#endif 


