#include<iostream>
#include<math.h>
#include"generalplayer.h"
#include"magi.h"
using namespace std;
magi::magi()
{
	level = 1;
	hp = 100;
	mp = 120;
	exp = 0;
	name = "anonymous";
};
magi::magi(int a)
{
	setAttr(a);
	name = "anonymous";
	exp = pow(10, log2(a - 1 + 1));
};
magi::magi(int a, string b)
{
	setAttr(a);
	exp = pow(10, log2(a - 1 + 1));
	name = b;
};
magi::magi(const magi&f)
{
	setLevel(f.level);
	hp = f.hp;
	mp = f.mp;
};
void magi::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void magi::setAttr(int a)
{
	if (a > 0)
	{
		max_hp = 120 + 20 * a;
		max_mp = 100 + 7 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 30 + 8 * a;
		defense = 25 + 7 * a;
	}
}
void magi::setLevel(int a)
{
	if (a > 0)
	{
		level = a;
		setAttr(a);
	}
}
void magi::pray() 
{
	//increasing MP (level*10) points by decreasing HP (level*5) points
	if (hp - level * 5 > 0) 
	{
		hp - level * 5;
		mp + level * 10;
		if (mp + level * 10 >= max_mp  ) 
		{
			mp = max_mp;
		}
	}
}