#include<iostream>
#include <math.h>
#include"generalplayer.h"
using namespace std;
gp::gp()//default
{
	level = 1;
	hp = 100;
	mp = 50;
	exp = 0;
	name = "anonymous";
}
gp::gp(int a) //without name
{
	setAttr(a);
	name = "anonymous";
	exp = pow(10, log2(a - 1 + 1));
}
gp::gp(int a,string e)//with name
{
	setAttr(a);
	exp = pow(10, log2(a - 1 + 1));
	name = e;
}
gp::gp(const gp&f) //copy
{
	setLevel(f.level);
	hp = f.hp;
	mp = f.mp;
}
string gp::getName() //getname
{
	return name;
}
int gp::getAttack(void) const
{
	return attack;
}
int gp::getDefense(void) const
{
	return defense;
}
int gp::getMaxHP(void) const
{
	return max_hp;
}
int gp::getMaxMP(void) const
{
	return max_mp;
}
int gp::getmaxexp(void) const
{
	return max_exp;
}
int gp::getHP()
{
	return hp;
}
int gp::getExp()
{
	return exp;
}
int gp::getMP()
{
	return mp;
}
void gp::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void gp::setName(string a) 
{
	name = a;
}
void gp::setHP(int a) 
{
	hp = a;
}
void gp::setMP(int a) 
{
	mp = a;
}
void gp::setExp(int a) 
{
	exp = a;
}
void gp::setLevel(int a) 
{
	if (a > 0) 
	{
		level = a;
		setAttr(a);
	}
}
void gp::setAttr(int a) 
{
	if (a > 0)
	{
		max_hp = 100 + 10 * a;
		max_mp = 40 + 5 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 20 + 5 * a;
		defense = 20 + 5 * a;
	}
}
void gp::increaseHP(int a)
{
	if (hp + a > max_hp) { hp = max_hp; }
	else hp = hp + a;
}
void gp::increaseMP(int a) 
{
	if (mp + a > max_mp) { mp = max_mp; }
	else mp = mp + a;
}
void gp::increaseExp(int a)
{
	exp = exp + a;
	if (exp >= max_exp) 
	{
		while (true)
		{if(exp>=max_exp)
			levelUp();
		else break;
		}
	}
}
void gp::recoverHP(void) 
{
	hp = max_hp;
}
void gp::recoverMP(void)
{
	mp = max_mp;
} 


