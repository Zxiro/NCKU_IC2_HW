#include<iostream>
#include<math.h>
#include"generalplayer.h"
#include"knight.h"
using namespace std;
knight::knight()
{
	level = 1;
	hp = 180;
	mp = 35;
	exp = 0;
	name = "anonymous";
};
knight::knight(int a)
{
	setAttr(a);
	name = "anonymous";
	exp = pow(10, log2(a - 1 + 1));
};
knight::knight(int a, string b)
{
	setAttr(a);
	exp = pow(10, log2(a - 1 + 1));
	name = b;
};
knight::knight(const knight&f)
{
	setLevel(f.level);
	hp = f.hp;
	mp = f.mp;
};
void knight::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void knight::setAttr(int a)
{
	if (a > 0)
	{
		max_hp = 180 + 30 * a;
		max_mp = 35 + 5 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 50 + 8 * a;
		defense = 40 + 5 * a;
	}
}
void knight::setLevel(int a)
{
	if (a > 0)
	{
		level = a;
		setAttr(a);
	}
}
void knight::heal()
{
	//increasing MP (level*10) points by decreasing HP (level*5) points
	if (mp - level * 5 > 0)
	{
		mp - level * 5;
		hp + level * 10;
		if (hp + level * 10 >= max_hp)
		{
			hp = max_hp;
		}
	}
}