#include<iostream>
#include <math.h>
#include"generalplayer.h"
#include"orc.h"
using namespace std;
orc::orc() 
{
	level = 1;
	hp = 200;
	mp = 30;
	exp = 0;
	name = "anonymous";
};
orc::orc(int a) 
{
	setAttr(a);
	name = "anonymous";
	exp = pow(10, log2(a - 1 + 1));
};
orc::orc(int a, string b) 
{
	setAttr(a);
	exp = pow(10, log2(a - 1 + 1));
	name = b;
};
orc::orc(const orc&f) 
{
	setLevel(f.level);
	hp = f.hp;
	mp = f.mp;
};
void orc :: levelUp() 
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void orc::setAttr(int a) 
{
	if (a > 0)
	{
		max_hp = 200+ 20 * a;
		max_mp = 30 + 5 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 50 + 12 * a;
		defense = 30 + 10 * a;
	}
}
void orc::setLevel(int a)
{
	if (a > 0)
	{
		level = a;
		setAttr(a);
	}
}
