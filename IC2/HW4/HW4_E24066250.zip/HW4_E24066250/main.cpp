#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<sstream>
#include<iomanip>
#include"maze.h"
using namespace std;
int main()
{
	maze m;
	m.route(2, 2);
	
	return 0;
}
