﻿#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<sstream>
#include<iomanip>
#include"maze.h"
using namespace std;

maze::maze()
{
	fstream file;
	string line, in;
    cout << "plz enter the maze:";
	cin >> in;
	file.open(in, ios::in);
	if (!file)
	{
		cout << "Unable to read the file Plz check!!" << endl;
	}
	stringstream ss;//另一個儲存資料的地方
	while (getline(file, line))//抓字串string
	{
		/*cout << line << "line" << endl;
		cout << num << "num" << endl;*/
		vector <int> temp;
		ss << line;//line type string   
				   //fstream linen;
		string route;
		while (getline(ss, route, ','))//迴避逗號
		{
			//cout << route << "route" << endl;
			stringstream strtoint;
			int num;
			strtoint << route; strtoint >> num;
			temp.push_back(num);
		}
		okr.push_back(temp);
		ss.str("");
		ss.clear();
	}
	for (int i = 0; i < okr.size(); i++)//做出data//i=row
	{
		vector<int>tempa;
		for (int k = 0; k < okr[i].size(); k++)//k=col
		{
			tempa.push_back(0);
		}
	data.push_back(tempa);
		chd.push_back(tempa);
	}
	for (int i = 0; i < okr.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < okr[i].size(); k++)//k=col
		{
			if (okr[i][k] == 1)
			{
				okr[i][k] = 99;
			}
			if (okr[i][k] == 200)
			{
				data[i][k] = 1;
			}
			else continue;
		}
	}
}
void maze::print()
{
	if (end != 1) //還沒到終點-
	{
		for (int i = 1; i < okr.size(); i++)//玩家的地圖//i=row
		{
			for (int k = 0; k < okr[i].size(); k++)//k=col
			{
				if( okr[i][k] == 200)
				{
					cout << "STR ";
				}
				else if (data[i][k] == 4)
				{
					cout << " END";
					end = 1;
				}
				else if (data[i][k] == 3)
				{
					cout << setw(4) << "X";
				}
				else if (chd[i][k] == 1)
				{
					cout << setw(4) << "口";
				}
				else if (data[i][k] == 1)
				{
					cout << setw(4) << "●";
				}
				else if (okr[i][k] == 99)
				{
					cout << setw(4) << "■";
				}
				else if (end != 1)
				{
					cout << setw(4) << data[i][k];
				}
			}
			cout << endl;
		}
		system("cls");
	}
	if (end == 1)//到終點
	{
		for (int i = 1; i < okr.size(); i++)//玩家的地圖//i=row
		{
			for (int k = 0; k < okr[i].size(); k++)//k=col
			{
				if (okr[i][k] == 200)
				{
					cout << "STR ";
				}
				else if (data[i][k] == 4)
				{
					cout << " END";
				}
				else if (data[i][k] == 3)
				{
					cout << setw(4) << "X";
				}
				else if (chd[i][k] == 1)
				{
					cout << setw(4) << "口";
				}
				else if (data[i][k] == 1)
				{
					cout << setw(4) << "●";
				}
				else if (okr[i][k] == 99)
				{
					cout << setw(4) << "■";
				}
				else
				{
					cout << setw(4) << data[i][k];
				}
			}
			cout << endl;
		}
	}
	
}
int maze::route(int i, int k)//i&k okr的位置
{
	if (end != 1) {
		int drc = 0;
		if (okr[i][k] != 99)
		{
			if (k + 1 < okr[i].size() - 1 && k - 1 > -1 && i + 1 < okr.size() && i - 1 > 0)//死路計算
			{
				if (okr[i][k + 1] == 99) { drc++; }
				if (okr[i][k - 1] == 99) { drc++; }
				if (okr[i + 1][k] == 99) { drc++; }
				if (okr[i - 1][k] == 99) { drc++; }
			}
			if (drc >= 3) { data[i][k] = 3; }
			drc = 0;
		}
		if (okr[i][k] == 201)//終點計算
		{
			data[i][k] = 4;
		}
		print();
		if (end == 1)
		{
			cout << "point:" << poi << endl;
			system("pause");
			return 0;
		}
		if ((okr[i][k] == 0 && data[i][k] != 1 && data[i][k] != 3 && chd[i][k] != 1) || okr[i][k] > 201)//[i][k+1]ablepass [i][k]walked合法路徑
		{
			if (okr[i][k] > 201 && chd[i][k] == 0)
			{
				chd[i][k] = 1;
				poi++;//得分
			}
			data[i][k] = 1;
			route(i, k + 1);
			route(i + 1, k);
			route(i, k - 1);
			route(i - 1, k);
		}
	}
}
