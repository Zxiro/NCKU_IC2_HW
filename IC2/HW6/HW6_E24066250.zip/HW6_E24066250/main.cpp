﻿/*Double Version*/
#include<iostream>
#include"Matrix5.h"
using namespace std;
Matrix m;
int Matrix::count = 0;
void Matrix::setup(int r, int c)
{
	row = r; col = c;
	//cout << "row" << row << endl; cout << "col" << col << endl;
	setupm = new double *[r];
	//此矩陣有 r 個列(rows); 先 new 出 r個 int *
	for (int i = 0; i<r; i++)
	{
		setupm[i] = new double[c];
		//每一列有 c 行(columns); setupm[i] 指向新 new 出的 c 個 int
	}
	for (int i = 0; i < r; i++) 
	{
		for (int k = 0; k < c; k++) 
		{
			setupm[i][k] = 0;
		}
	}
	count++;
}
Matrix::~Matrix() {for (int i = 0; i<row; i++)
	{
		delete[] setupm[i];
	}
	delete[] setupm;
	count--;
}
Matrix::Matrix() 
{
	setup(2, 2);
}
Matrix::Matrix(int r, int c)
{
	setup(r, c);
}
Matrix::Matrix(int r, int c, double a[], int rc)
{
	setup(r, c);
	rc = r * c;
	int k = 0;
	for (int z = 0; z < r; z++)
	{
		for (int y = 0; y < c; y++)
		{
			setupm[z][y] = a[k];
			k++;
		}
	}
}
Matrix::Matrix(const Matrix &m) 
{
	setup(m.row, m.col);
	for (int i = 0; i <m.row; i++)
	{
		for (int k = 0; k <m. col; k++)
		{
			setupm[i][k] = m.setupm[i][k];
		}
	}
}
void Matrix::setData(int r, int c, double i) 
{
	setupm[r][c] = i;
}
double Matrix::getData(int r, int c)const 
{
	return setupm[r][c];
}
int Matrix::getRow() const 
{
	int r;
	r = row;
	return r;
}
int Matrix::getCol() const
{
	int c;
	c = col;
	return c;
}
ostream &operator <<(ostream &out, const Matrix &m) 
{
	out << endl;
		for (int i = 0; i<m.row; i++) 
		{
			for (int j = 0; j <m.col; j++) 
			{
				out << m.setupm[i][j];
				out << "\t";
			}
			out << "" << endl;
		}
	return out;
}
istream &operator >>(istream &in, Matrix &m)
{
	for (int i = 0; i<m.row; i++)
	{
		for (int j = 0; j <m.col; j++)
		{
			in>>m.setupm[i][j];
		}
	}
	return in;
}
bool Matrix::operator ==(const Matrix &m) 
{
	int trcount=0;
	for (int i = 0; i<m.row; i++)
	{
		for (int j = 0; j <m.col; j++)
		{
			if (setupm[i][j] != m.setupm[i][j]) 
			{ 
				trcount++; 
				break;
			}
		}
	}
	if (trcount == 0) { return true; }
	else if (trcount != 0)return false;
}
Matrix Matrix:: operator+(Matrix &m) 
{
	Matrix tem(row,col);
	for (int i = 0; i<m.row; i++)
	{
		for (int j = 0; j <m.col; j++)
		{
			tem.setupm[i][j]=setupm[i][j] + m.setupm[i][j];
		}
	}
	return tem;
}
Matrix Matrix:: operator+(double c)
{
	Matrix tem(row, col);
	
	for (int i = 0; i<row; i++)
	{
		for (int j = 0; j <col; j++)
		{
			tem.setupm[i][j] = setupm[i][j] + c;
		}
	}
	return tem;
}
Matrix Matrix::operator ++(int b)
{
	Matrix tem(row,col);
	for (int i = 0; i<tem.row; i++)
	{
		for (int j = 0; j <tem.col; j++)
		{
			tem.setupm[i][j]=setupm[i][j] + 1;
		}
	}
	return tem;
}
Matrix Matrix::operator+=(Matrix &m) 
{
	for (int i = 0; i<m.row; i++)
	{
		for (int j = 0; j <m.col; j++)
		{
			setupm[i][j] = setupm[i][j] + m.setupm[i][j];
		}
	}
	return *this;
}
Matrix Matrix ::operator =(Matrix m)
{
	for (int i = 0; i<m.row; i++)
	{
		for (int j = 0; j <m.col; j++)
		{
			setupm[i][j] = m.setupm[i][j];
		}
	}
	return*this;
}
Matrix Matrix ::operator *(Matrix m)
{
	Matrix a(row, m.col);
	double z = 0;
	for (int i = 0; i < row; i++) //原本的row
	{
		for (int j = 0; j < m.col; j++) //相乘的col
		{
			for (int k = 0; k < col; k++)//原本的col
			{
				z = z + setupm[i][k] * m.setupm[k][j];
			}
			a.setupm[i][j] = z;
			z = 0;
		}
	}
	return a;
}
Matrix Matrix ::operator ()()
{
	Matrix tem(col, row);//設置一個全是0的轉至矩陣
	for (int i = 0; i < tem.row; i++)
	{
		for (int k = 0; k <tem.col; k++)
		{
			tem.setupm[i][k] = setupm[k][i];
		}
	}
	return tem;
}
int Matrix::getCount() { return count; }
int main()
{
	Matrix m1;

	double d[9] = { 1,2,3,4,5,6,7,8,9 };

	Matrix m2(3, 3, d, 9);
	Matrix m3(m2);

	cout << "Matrix m1 is : " << endl;
	m1.displayData();
	cout << "Matrix m2 is : " << m2 << endl;
	cout << "Matrix m3 is : " << m3 << endl;

	if (m2 == m3)
		cout << "m2 and m3 are the same.";
	else
		cout << "m2 and m3 are different";
	
	m3.setData(1, 1, 99);
	cout << "m3 after setup is : " << m3 << endl;
	if (m2 == m3)
		cout << "m2 and m3 are the same.";
	else
		cout << "m2 and m3 are different";

	Matrix m4(3, 3);
	cout << "Please enter 9 doubles for matrix m4:" << endl;
	cin >> m4;
	cout << "Matrix m4 is : " << m4 << endl;

	Matrix m5 = m2 + m3;
	cout << "m2+m3 is : " << m5 << endl;

	m5 = m2 + 3;
	cout << "m2 + 3 is : " << m5 << endl;
	
	m5 += m2;
	cout << "m2 + m2 + 3 is : " << m5 << endl;

	m5++;
	cout << "m2 + m2 + 4 is : " << m5 << endl;
	
	m5 = m2 * m3;
	cout << "m2 * m3 is : " << m5 << endl;

	m5 = m2();
	cout << "transpose of m2 is : " << m5 << endl;

	cout << "number of matrices now is : " << Matrix::getCount() << endl;

	system("pause");
	return 0;
}


