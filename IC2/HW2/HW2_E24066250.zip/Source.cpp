#include<iostream>
#include<vector>
#include<stdlib.h>
#include<iomanip>
using namespace std;
vector<vector<int>>map;
vector<vector<int>>show;
vector<vector<int>>press;
void mineweeper(int, int);
int x, y,rule;
int main(void)
{
	srand(time(NULL));
	int bc = 0;
	int bcy, bcx;
	cout << "�п�J�a�ϼe��" << endl;
	cin >> x;
	cout << "�п�J�a�Ϫ���" << endl;
	cin >> y;
	cout << "�Q�n�����u�ƶq(�ƶq���i�W�L�a�Ϥj�p)" << endl;
	cin >> bc;
cout << endl << endl << endl << endl << endl;
	s:for (int i = 0; i <= y + 1; i++)
	{
		vector<int>tem;
		for (int k = 0; k <= x + 1; k++)
		{
			tem.push_back(0);
		}
		map.push_back(tem);
		press.push_back(tem);
	}
	  for (int i = 0; i <= y + 1; i++)
	  {
		  vector<int>tem;
		  for (int k = 0; k <= x + 1; k++)
		  {
			  tem.push_back(99);
		  }
		 
		  show.push_back(tem);
		
	  }
	for (int i = 0; i < map.size(); i++)
	{
		for (int k = 0; k < map[i].size(); k++)
		{
			if (i == 0 || k == 0)
			{
				map[i][k] = -2;
				show[i][k] = -2;
			}
			else if (i == map.size() - 1 || k == map[i].size() - 1)
			{
				map[i][k] = -2;
				show[i][k] = -2;
			}
		}
	}
	for (int b = 0; b < bc; b++) //�H���䬵�u��m
	{

		bcy = (rand() % y) + 1;
		bcx = (rand() % x) + 1;
		if (map[bcy][bcx] != -1 && map[bcy][bcx] != -2)
		{
			map[bcy][bcx] = -1;
			if (map[bcy + 1][bcx] != -1 && bcy + 1 <= y)
			{
				if (map[bcy + 1][bcx] != -2)
					map[bcy + 1][bcx]++;
			}
			if (map[bcy][bcx + 1] != -1 && bcx + 1 <= x)
			{
				if (map[bcy][bcx + 1] != -2)
					map[bcy][bcx + 1] ++;
			}
			if (map[bcy - 1][bcx] != -1 && bcy - 1 >= 1)
			{
				if (map[bcy - 1][bcx] != -2)
					map[bcy - 1][bcx] ++;
			}
			if (map[bcy][bcx - 1] != -1 && bcx - 1 >= 1)
			{
				if (map[bcy][bcx - 1] != -2)
					map[bcy][bcx - 1] ++;
			}
			if (map[bcy + 1][bcx + 1] != -1 && bcy + 1 <= y && bcx + 1 <= x)
			{
				if (map[bcy + 1][bcx + 1] != -2)
					map[bcy + 1][bcx + 1] ++;
			}
			if (map[bcy - 1][bcx - 1] != -1 && bcy - 1 >= 1 && bcx - 1 >= 1)
			{
				if (map[bcy - 1][bcx - 1] != -2)
					map[bcy - 1][bcx - 1] ++;
			}
			if (map[bcy + 1][bcx - 1] != -1 && bcy + 1 <= y && bcx - 1 >= 1)
			{
				if (map[bcy + 1][bcx - 1] != -2)
					map[bcy + 1][bcx - 1] ++;
			}
			if (map[bcy - 1][bcx + 1] != -1 && bcx - 1 <= x && bcy + 1 >= 1)
			{
				if (map[bcy - 1][bcx + 1] != -2)
					map[bcy - 1][bcx + 1] ++;
			}
		}
		else
		{
			b--;
			continue;
		}
	}
	for (int i = 0; i < map.size(); i++)
	{
		for (int k = 0; k < map[i].size(); k++)
		{
			cout << setw(4) << map[i][k];
		}
		cout << endl << endl;
	}
	cout << "��a��" << endl;
	for (int i = 1; i < map.size(); i++)
	{
		for (int k = 1; k < map[i].size(); k++)
		{ if (i == map.size() - 1 || k == map[i].size() - 1)
			{
				continue;
			}
			cout << setw(4) << "��";
			
		}
		cout << endl<<endl;
	}
	cout << "���a��" << endl;
	while (true)
	{
		cout << "��ܧA����m" << endl;
		int ux, uy;//x��
	xx:cout << "x= ";
		cin >> ux;
		if (ux > x)
		{
			cout << "Out of range! plz enter again" << endl;
			goto  xx;
		}
	yy:cout << "y=";
		cin >> uy;
		if (uy > y)
		{
			cout << "Out of range! plz enter again" << endl;
			goto  yy;
		}
		//cout << map[uy][ux] << endl;
		show[uy][ux] = map[uy][ux];
		if (map[uy][ux] == -1)
		{
			show[uy][ux] = -1;
			cout << "BANG!!!" << endl;
			for (int i = 1; i < map.size(); i++)
			{
				for (int k = 1; k < map[i].size(); k++)
				{
					if (i == map.size() - 1 || k == map[i].size() - 1)
					{
						continue;
					}
					if (map[i][k] == 1) 
					{
						map[i][k] = 0;
					}
					else if (map[i][k] != -2 && map[i][k] != -1)
					{ map[i][k] = 0;
					}
						cout << setw(4) << map[i][k];
				}
				cout << endl << endl;
			}
			goto end;
		}
		if (map[uy][ux] == 0)//�S���F��
		{
			//cout << map[uy][ux] << endl;
			mineweeper(uy, ux);
			cout << "SAFE" << endl;
		}
		for (int i = 1; i < map.size(); i++)
		{
			for (int k = 1; k < map[i].size(); k++)
			{
				if (i == map.size() - 1 || k == map[i].size() - 1)
				{
					continue;
				}
				if (show[i][k]==99)
				{
					cout << setw(4) << "��";
					continue;
				}
				cout << setw(4) << show[i][k];
		    
			}
			cout << endl << endl;
		}
		system("pause");
		system("cls");
	}
end:cout << "Gmae Over!!" << endl;
	system("pause");

}
void mineweeper(int uy, int ux) //uy�W�U ux���k
{
	for (int i = -1; i <= 1; i++)
	{
		for (int k = -1; k <= 1; k++)
		{
			/*cout << "112" << endl;
			cout << uy + i << "yyy" << endl;
			cout << ux + k << "xxx" << endl;*/
			if (i==0&&k==0) 
			{
				continue;
			}
			else if (uy + i == 0 || ux + k == 0) { continue; }
			else if (uy + i <= y && uy + i >= 1 && ux + k <= x && ux + k >= 1) 
			{
				//cout << "113" << endl;
				//cout << map[uy + i][ux + k] << " !!" << endl;
				if (map[uy + i][ux + k] != 0 && map[uy + i][ux + k] != -2 && map[uy + i][ux + k] != -1)
				{
					//cout << map[uy + i][ux + k] << " ??" << endl;
					
					show[uy + i][ux + k] = map[uy + i][ux + k]; 
					continue;
				}
				else if (map[uy + i][ux + k] == 0) 
				{
					show[uy + i][ux + k] = 0;
					//cout << "114" << endl;
					//cout << uy + i << ux + k << "bug" << endl;
					if (press[uy + i][ux + k] != 1) {
						press[uy + i][ux + k] = 1;
						mineweeper(uy + i, ux + k);
					}
					
					else continue;
				}
				else if (map[uy + i][ux + k] == -2)
				{
					//cout << uy + i << ux + k << "bug2" << endl;
					//cout << "115" << endl;
					continue;
				}
				else continue;
			}
			
			
		}
	}
}
