#include<iostream>
#include<string>
#include<random>
#include<time.h>
#include"absmon.h"
#include"zombie.h"
#include"boss.h"
#include"goblin.h"
#include"magi.h"
#include"knight.h"
#include"orc.h"
#include"generalplayer.h"
using namespace std;
class gp; class absmon;
#ifndef battle_h
#define battle_h
struct character
{
	char type;//mon or gp
	bool live;
	void *instance;//point to instance
};
class battle 
{
	
public :
	battle(gp**, absmon**, int, int, int);
	bool nextact(void);//�U�@��
	int getturn(void)const;
	int getlimturn(void)const;
	int getgpcount(void)const;
	int getgpcount(bool)const;
	int getmoncount(void)const;
	int getmoncount(bool)const;
	void showfield(void);
	character getcurrentactor(void);
	character* getgp(void);
	character* getmon(void);
private:
	int actturn = 0;
	int plyc;
	int monc;
	int turn = 0;
	int limturn;
	character * actlist;
};
#endif
