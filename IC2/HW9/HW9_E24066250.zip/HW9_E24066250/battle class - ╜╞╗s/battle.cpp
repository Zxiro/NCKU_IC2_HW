#include<iostream>
#include<string>
#include<random>
#include<time.h>
#include"absmon.h"
#include"zombie.h"
#include"boss.h"
#include"goblin.h"
#include"magi.h"
#include"knight.h"
#include"orc.h"
#include"generalplayer.h"
#include"battle.h"
using namespace std;
battle::battle(gp** ply, absmon** mon, int a, int b, int c)
{
	limturn = c;
	plyc = a;
	monc = b;
	actturn=0;
	actlist = new character[a + b];//a+b��character
	for (int i = 0; i <= a - 1; i++) 
	{
		actlist[i].type = 'p';
		actlist[i].live = 1;
		actlist[i].instance = ply[i];//�V�L�@�hpointer
	}
	for (int i = a; i < a + b; i++) 
	{
		actlist[i].type = 'm';
		actlist[i].live = 1;
		actlist[i].instance = mon[i-a];
	}
}
void battle::showfield(void) 
{
	for (int i = 0; i < plyc; i++)//���a����
	{
		if (actlist[i].live == 1)
		{
			gp*temp;
			temp = static_cast<gp*>(actlist[i].instance);
			cout << "====================================" << endl;
			cout << i+1 << endl;
			temp->attr();
			cout << "====================================" << endl;
		}
	}
	for (int i = plyc; i < plyc + monc; i++)//�Ǫ�����
	{
		if (actlist[i].live == 1)
		{
			absmon*tempm;
			tempm = static_cast<absmon*>(actlist[i].instance);
			cout << "====================================" << endl;
			cout << i-plyc+1 << endl;
			tempm->attr();
			cout << "====================================" << endl;
		}
		
	}

}
int battle::getturn(void)const
{
	return turn;
}
int battle::getlimturn(void)const 
{
	return limturn;
}
int battle::getgpcount(void)const 
{
	return plyc;
}
int battle::getgpcount(bool life)const 
{ 
	int tempc=0;
	if (life == 1) 
	{
		for (int i = plyc; i < monc+plyc; i++)
		{
			if (actlist[i].live == 1)
			{
				tempc ++;
			}
		}
		return tempc;
	}
	else if (life == 0) 
	{
		return plyc;
	}
}
int battle::getmoncount(void)const 
{
	return monc;
}
int battle::getmoncount(bool life)const 
{
	int tempc = 0;
	if (life == 1)
	{
		for (int i = 0; i <= plyc - 1; i++)
		{
			if (actlist[i].live == 1)
			{
				tempc++;
			}
		}
		return tempc;
	}
	else if (life == 0)
	{
		return monc;
	}
}
bool battle::nextact(void)
{
	actturn++;
	int tem;
	char at;
	if (actturn > plyc + monc) 
	{
		turn++;
		actturn = 0;
	}
	showfield();
	while (true)
	{
		for (int i = 0; i < plyc; i++)//���a����
		{
			cout << endl;
			cout << "��ܧA�n�������Ǫ�:";
			cin >> tem;
	        
			cout << endl;
			cout << "��ܧA�n�������覡:" << endl;
			cout << "a�����q����,s���ޯ�" << endl;
			cin >> at;
			if (at == 'a')
			{

			}
			else if (at == 's')
			{

			}
		}
		for (int i = plyc; i < plyc + monc; i++)//�Ǫ�����
		{
			if (actlist[i].live == 1)
			{

			}
		}
	}
	return 1;
}
character battle::getcurrentactor(void) 
{
	return actlist[actturn];//actlist�ĴX�ӴN�N�����ӤH�Ω�
}
character*battle::getgp(void)
{
	character*tem = new character[plyc];
	for (int i = 0; i < plyc; i++) 
	{
		tem[i] = actlist[i];
	}
	return tem;
}
character*battle::getmon(void)
{
	character*tem = new character[monc];
	for (int i = plyc,j=0; i < monc,j<monc; i++,j++)
	{
		tem[j] = actlist[i];
	}
	return tem;
}

