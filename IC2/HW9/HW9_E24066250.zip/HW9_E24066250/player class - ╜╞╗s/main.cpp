#include<iostream>
#include<string>
#include<random>
#include<time.h>
#include"absmon.h"
#include"zombie.h"
#include"boss.h"
#include"goblin.h"
#include"magi.h"
#include"knight.h"
#include"orc.h"
#include"generalplayer.h"
#include"battle.h"
using namespace std;
int main(void) 
{
	knight k(3,"NEW ");
	gp*kptr = &k;
	orc o(3,"ORC");
	gp*optr = &o;
	goblin g;
	absmon*gptr = &g;
	zombie z;
	absmon*zptr = &z;
    boss b;
	absmon*bptr = &b;
	gp**plist = new gp*[2];
	plist[0] = &k;
	plist[1] = &o;
	absmon**mlist = new absmon*[3];
	mlist[0] = &g;
	mlist[1] = &z;
	mlist[2] = &b;
	battle a(plist, mlist, 2, 3, 100);
	while(true)
	{
		a.nextact();
		system("pause");
		system("cls");
	}
	
}