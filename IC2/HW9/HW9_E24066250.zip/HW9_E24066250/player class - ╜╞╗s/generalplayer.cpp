#include<iostream>
#include <math.h>
#include"generalplayer.h"
#include"absmon.h"
#include<random>
#include<time.h>
#include<sstream>
#include<fstream>
using namespace std;
void gp::setmoney(int a)
{
	money = a;
}
int gp:: getmoney()const 
{
	return money;
}
void gp::unserial(string a) 
{

}
gp::gp()//default
{
	level = 1;
	setHP(100);
	setMP(50);
	setExp(0);
	setmoney(0);
	setName("anonymous");
}
gp::gp(int a) //without name
{
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setName("anonymous");
	setmoney(0);
	setExp(pow(10, log2(a - 1 + 1)));
}
gp::gp(int a,string e)//with name
{
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setmoney(0);
	setExp(pow(10, log2(a - 1 + 1)));
	setName(e);
}
gp::gp(const gp&f) //copy
{
	setLevel(f.level);
	setHP(f.getHP());
	setMP(f.getMP());
	setExp(f.getExp());
	setAttr(f.level);
	setName(f.name);
	setmoney(0);
}
string gp::getName()const //getname
{
	return name;
}
int gp::getlevel(void)const 
{
	return level;
}
int gp::getAttack(void) const
{
	return attack;
}
int gp::getDefense(void) const
{
	return defense;
}
int gp::getMaxHP(void) const
{
	return max_hp;
}
int gp::getMaxMP(void) const
{
	return max_mp;
}
int gp::getmaxexp(void) const
{
	return max_exp;
}
int gp::getHP()const
{
	return hp;
}
int gp::getExp()const
{
	return exp;
}
int gp::getMP()const
{
	return mp;
}
void gp::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void gp::setName(string a) 
{
	name = a;
}
void gp::setHP(int a) 
{
	hp = a;
}
void gp::setMP(int a) 
{
	mp = a;
}
void gp::setExp(int a) 
{
	exp = a;
}
void gp::setLevel(int a) 
{
	if (a > 0) 
	{
		level = a;
		setAttr(a);
		cout << level;
	}
	else if (a <= 0) {
		level = 1; setAttr(1);
		cout << level;
	}
}
void gp::setAttr(int a) 
{
	if (a > 0)
	{
		max_hp = 100 + 10 * a;
		max_mp = 40 + 5 * a;
		max_exp = pow((log2(a + 1)), 2) * 100;
		attack = 20 + 5 * a;
		defense = 20 + 5 * a;
	}
}
void gp::increaseHP(int a)
{
	if (hp + a > max_hp) { hp = max_hp; }
	else hp = hp + a;
}
void gp::increaseMP(int a) 
{
	if (mp + a > max_mp) { mp = max_mp; }
	else mp = mp + a;
}
void gp::increaseExp(int a)
{
	exp = exp + a;
	if (exp >= max_exp) 
	{
		while (true)
		{
			if(exp>=max_exp)
			levelUp();
		else 
			break;
		}
	}
}
void gp::recoverHP(void) 
{
	hp = max_hp;
}
void gp::recoverMP(void)
{	
	mp = max_mp;
} 
void gp::skill() {};
void gp::attackTo(absmon*m) 
{
	srand(time(NULL));
	int dam;
	int a = (rand() % 2);
	switch (a) 
	{
	case(0):
		dam = (attack - m->getdef())*1.1;
		cout << attack << "Player ATT" << endl;
		cout << endl << endl;
		cout << m->getdef() << "Mon DEF" << endl;
		cout << endl << endl;
		cout << dam << endl << "1.1��" << endl;
		cout << endl << endl;
		break;
	case(1):
		dam = (attack - m->getdef())*0.9;
		cout << attack << "Player ATT"  << endl;
		cout << endl << endl;
		cout << m->getdef() << "Mon DEF" << endl;
		cout << endl << endl;
		cout << dam << endl << "0.9��" << endl;
		cout << endl << endl;
		break;
	}
	if (dam >= 0)
	m->sethp(m->gethp()-dam);
	if (m->gethp() < 0) 
	{
		cout << "Player Gold: " << getmoney() << endl << endl;
		cout << "Player EXP: " << getExp() << endl << endl;
		setExp(getExp() + m->exp);
		cout << "GET EXP: " << m->exp << endl << endl;
		cout << "Total Player EXP: " << getExp() << endl << endl;
		setmoney(money+ m->money);
		cout << "GET Gold: " << m->money << endl << endl;
		cout << "Total Player Gold: " << getmoney() << endl<<endl;
	}
}
void gp::attr()
{
	cout << "NAME: " << name << endl << endl << "HP: " << hp << endl << endl << "MP: " << mp << endl << endl << "DEF: " << defense << endl << endl << "ATT: " << attack << endl<<endl<<"Money: "<<money<<endl;
}//��o��T
string gp::serial()const 
{
	string t;
	string data="PD:";
	stringstream s;
	s << getlevel();
	s >> t;
	data = data + t+",";
	s.str("");
	s.clear();
	t.clear();
	cout << getlevel() << endl;
	s << getHP();
	s >> t;
	data = data  + t + ",";
	s.str("");
	s.clear();
	t.clear();
	cout << getHP() << endl;
	s << getMP();
	s >> t;
	data = data  + t + ",";
	s.str("");
	s.clear();
	t.clear();
	cout << getMP() << endl;
	if (getmoney() == 0) 
	{
		t = '0';
		data = data  + t;
	}
	else if (getmoney() != 0)
	{
		s << getmoney();
		s >> t; data = data + t ;
		cout << getmoney() << endl;
		s.str("");
		s.clear();
		t.clear();
	}
	string file = "filedata.txt";
	fstream f;
	f.open(file, ios::out);
	f << data;
	f.close();
	return data;
}
void unserial(string s) 
{
	fstream file;
	string filename = { "filedata.txt" };
	file.open(filename, ios::in);

	char abc;

	file >> name >> abc >> level >> abc >> hp >> abc >> mp >> abc >> exp >> abc >> money;




	file.close();
}


