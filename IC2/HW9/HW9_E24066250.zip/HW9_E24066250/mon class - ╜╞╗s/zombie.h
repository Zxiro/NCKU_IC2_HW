#include<iostream>
#include<string>
#include"generalplayer.h"
#include"absmon.h"
using namespace std;
#ifndef zombie_h
#define zombie_h
class zombie :public absmon
{
public:
	zombie();
	~zombie();
	virtual void attackto(gp*p);
};
#endif

