#include<iostream>
#include<string>
#include<time.h>
#include"generalplayer.h"
#include"zombie.h"
using namespace std;
zombie::zombie()
	:absmon("zombie",50,65,17,150,30,100)
{
	sethp(max_hp); setmp(max_mp);
}
zombie::~zombie()
{
	count--;
}
void zombie::attackto(gp*p)
{
	srand(time(NULL));
	int dam;
	int a = (rand() % 3), b = (rand() % 2);
	switch (a)
	{
	case(0):
		switch (b)
		{
		case(0):
			dam = (attack - p->getDefense())*1.1;
			cout << attack << "Mon ATT" << endl;
			cout << endl << endl;
			cout << p->getDefense() << "Player DEF" << endl;
			cout << endl << endl;
			cout << dam <<endl<< "1.1��" << endl;
			cout << endl << endl;
			break;
		case(1):
			dam = (attack - p->getDefense())*0.9;
			cout << attack << "Mon ATT" << endl;
			cout << endl << endl;
			cout << p->getDefense() <<"Player DEF" << endl;
			cout << endl << endl;
			cout << dam << endl << "0.9��" << endl;
			cout << endl << endl;
			break;
		case(2):
			dam = (attack - p->getDefense());
			cout << attack << "Mon ATT" << endl;
			cout << endl << endl;
			cout << p->getDefense() <<"Player DEF" << endl;
			cout << endl << endl;
			cout << dam << endl << "1��" << endl;
			cout << endl << endl;
			break;
		}
		break;
	case(1):
		dam = (attack * 2 - p->getDefense());
		cout << attack << "att" << endl;
		cout << endl << endl;
		cout << p->getDefense() << "def" << endl;
		cout << endl << endl;
		cout << dam << endl << "2��" << endl;
		cout << endl << endl;
		setmp(getmp() - 10);
			break;
	}
	if (dam >= 0)
	p->setHP(p->getHP() - dam);
}
