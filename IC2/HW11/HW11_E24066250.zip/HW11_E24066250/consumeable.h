#include<iostream>
#include"generalplayer.h"
using namespace std;
#ifndef consume_h
#define consume_h
class consume
{
public:
	void use(gp*);
};
#endif