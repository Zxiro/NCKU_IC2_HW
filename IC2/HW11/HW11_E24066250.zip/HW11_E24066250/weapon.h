#include<iostream>
#include"item.h"
using namespace std;
#ifndef weapon_h
#define weapon_h
class weapon :item
{
public:
	const int attack_increment;
};
#endif
