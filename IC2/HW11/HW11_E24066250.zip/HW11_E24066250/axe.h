#include<iostream>
#include"weapon.h"
using namespace std;
#ifndef axe_h
#define axe_h
class axe :weapon
{
   axe(int);
};
#endif
