#include<iostream>
#include"tunic.h"
#include<string>


using namespace std;

axe::axe(int n) :