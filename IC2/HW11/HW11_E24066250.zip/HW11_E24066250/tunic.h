#include<iostream>
#include"armor.h"
using namespace std;
#ifndef tunic_h
#define tunic_h
class tunic :armor
{

};
#endif