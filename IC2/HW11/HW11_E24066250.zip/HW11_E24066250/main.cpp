#include<iostream>
#include <math.h>
#include"generalplayer.h"
#include"absmon.h"
#include<random>
#include<time.h>
#include<sstream>
#include<fstream>
#include"battle.h"
#include"boss.h"
#include"goblin.h"
#include"knight.h"
#include"magi.h"
#include"orc.h"
#include"zombie.h"
#include"maze.h"
using namespace std;
int main(void) 
{
	magi p1(3,"magi");
	knight p2(5,"knight");
	zombie m1;
	zombie m2;
	zombie m3;
	goblin m4;
	goblin m5;
	goblin m6;
	boss b1;
	boss b2;
	absmon** monlist1;
	gp** gplist1;
	maze g;
	maze *ptr = &g;
	gplist1 = new gp*[2];
	gplist1[0] = &p1;
	gplist1[1] = &p2;
	monlist1 = new absmon*[2];
	monlist1[0] = &m1;
	monlist1[1] = &m4;
	battle b(gplist1, monlist1, 2, 2, 0);
	while (true)
	{
		g.move();
	   if (ptr->getdata() == 5)
	   {
		   b.nextact();
	   }
	   else continue;
	}
}