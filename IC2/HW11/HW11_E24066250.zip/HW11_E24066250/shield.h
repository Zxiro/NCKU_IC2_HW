#include<iostream>
#include"armor.h"
using namespace std;
#ifndef shield_h
#define shield_h
class shield :armor
{

};
#endif