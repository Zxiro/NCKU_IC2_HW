#include<iostream>
#include<string>
#include<random>
#include"generalplayer.h"
#include"absmon.h"
using namespace std;
#ifndef boss_h
#define boss_h
class boss :public absmon
{
public:
	void setmoney();
      boss();
	  ~boss();
	  virtual void attackto(gp*);
};
#endif

