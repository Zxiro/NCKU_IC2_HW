#include<iostream>
#include<string>
#include<time.h>
#include<random>
#include"generalplayer.h"
#include"goblin.h"
using namespace std;
goblin::goblin()
	:absmon("goblin",60,40,12,100,50,60)
{
	sethp(max_hp); 
	setmp(max_mp);
}
goblin::~goblin()
{
	count--;
}
void goblin::attackto(gp*p) 
{
	srand(time(NULL));
	int dam;
	int a = (rand() % 3);
	switch (a)
	{
	case(0):
		dam = (attack - p->getDefense())*1.1;
		cout << attack <<"Mon ATT" << endl;
		cout << endl << endl;
		cout << p->getDefense() <<"Player DEF" << endl;
		cout << endl << endl;
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	case(1):
		dam = (attack - p->getDefense())*0.9;
		cout << attack << "Mon ATT" << endl;
		cout << endl<<endl;
		cout << p->getDefense() << "Player DEF" << endl;
		cout << endl << endl;
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	case(2):
		dam = (attack - p->getDefense());
		cout << attack << "Mon ATT" << endl;
		cout << endl << endl;
		cout << p->getDefense() << "Player DEF" << endl;
		cout << endl << endl;
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	}
	if (dam >= 0)
	p->setHP(p->getHP() - dam);
	if (p->getHP() < 0)
	{
		cout << "���a���`" << endl << endl;
	}
}