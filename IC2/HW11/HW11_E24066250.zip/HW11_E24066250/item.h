#include<iostream>
using namespace std;
#ifndef item_h
#define item_h
class item 
{
public:
	const int level_required;
	const string name;
	const string effect;
	const string description;
	const int weight;
	const char type;
};
#endif
