#include<iostream>
#include"axe.h"
#include<string>


using namespace std;

axe::axe(int n) :
	weapon(n)
{
	

}