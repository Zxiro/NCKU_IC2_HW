#include<iostream>
#include"consumeable.h"
using namespace std;
#ifndef magicpotion_h
#define magicpotion_h
class magicpotion :consume
{

};
#endif
