#include<iostream>
#include"weapon.h"
using namespace std;
#ifndef sword_h
#define sword_h
class sword :weapon 
{
	sword(int);
};
#endif

