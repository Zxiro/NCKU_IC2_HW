#include<iostream>
#include"consumeable.h"
using namespace std;
#ifndef lifepotion_h
#define lifepotion_h
class lifepotion :consume
{

};
#endif