#include<iostream>
#include"shield.h"
#include<string>


using namespace std;

axe::axe(int n) :