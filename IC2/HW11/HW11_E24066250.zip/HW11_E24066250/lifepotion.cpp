#include<iostream>
#include"lifepotion.h"
#include<string>


using namespace std;
