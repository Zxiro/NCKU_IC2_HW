#include<iostream>
#include<string>
#include<random>
#include<time.h>
#include<windows.h>
#include"absmon.h"
#include"zombie.h"
#include"boss.h"
#include"goblin.h"
#include"magi.h"
#include"knight.h"
#include"orc.h"
#include"generalplayer.h"
#include"battle.h"
using namespace std;
gp*p;
absmon*m;
void gotoxy(int xpos, int ypos)
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = xpos; scrn.Y = ypos;
	SetConsoleCursorPosition(hOuput, scrn);
}
battle::battle(gp** ply, absmon** mon, int a, int b, int c)
{
	limturn = c;
	plyc = a;
	monc = b;
	actturn=0;
	actlist = new character[a + b];//a+b��character
	for (int i = 0; i <= a - 1; i++) 
	{
		actlist[i].type = 'p';
		actlist[i].live = 1;
		actlist[i].instance = ply[i];//�V�L�@�hpointer
	}
	for (int i = a; i < a + b; i++) 
	{
		actlist[i].type = 'm';
		actlist[i].live = 1;
		actlist[i].instance = mon[i-a];
	}
}
int battle::getturn(void)const
{
	return turn;
}
int battle::getlimturn(void)const 
{
	return limturn;
}
int battle::getgpcount(void)const 
{
	return plyc;
}
int battle::getgpcount(bool life)const 
{ 
	int tempc=0;
	if (life == 1) 
	{
		for (int i = plyc; i < monc+plyc; i++)
		{
			if (actlist[i].live == 1)
			{
				tempc ++;
			}
		}
		return tempc;
	}
	else if (life == 0) 
	{
		return plyc;
	}
}
int battle::getmoncount(void)const 
{
	return monc;
}
int battle::getmoncount(bool life)const 
{
	int tempc = 0;
	if (life == 1)
	{
		for (int i = 0; i <= plyc - 1; i++)
		{
			if (actlist[i].live == 1)
			{
				tempc++;
			}
		}
		return tempc;
	}
	else if (life == 0)
	{
		return monc;
	}
}
void battle::showfield(int x,int y)
{
	for (int i = 0; i < plyc; i++)//���a
	{
		if (actlist[i].live == 1)
		{
			p = static_cast<gp*>(actlist[i].instance);
			gotoxy(x-19, y);
			cout << "========================" << endl;
			gotoxy(x - 19,y+1+i);
			cout << "NAME: " << p->getName;
			gotoxy(x - 19, y+2);
			cout<< "HP: " << p->getHP;
			gotoxy(x - 19, y+3);
			cout << "MP: " << p->getMP;
			gotoxy(x - 19, y+4);
			cout << "DEF: " << p->getDefense;
			gotoxy(x - 19, y+5);
			cout << "ATT: " << p->getAttack;
			gotoxy(x - 19, y+6);
			cout << "Money: " << p->getmoney;
			gotoxy(x - 19, y+7);
			cout << "========================" << endl;
		}
	}
	for (int i = plyc; i < plyc + monc; i++)//�Ǫ�
	{
		if (actlist[i].live == 1)
		{
			m = static_cast<absmon*>(actlist[i].instance);
			gotoxy(x, y+10);
			cout << "========================" << endl;
			gotoxy(x, y+11);
			cout << "NAME: " << m->name;
			gotoxy(x, y+12);
			cout << "HP: " << m->gethp;
			gotoxy(x, 28);
			cout << "MP: " << m->getmp;
			gotoxy(x, 29);
			cout << "DEF: " << m->getdef;
			gotoxy(x, 30);
			cout << "ATT: " << m->attack;
			gotoxy(x, 31);
			cout << "========================" << endl;
		}
	}
}
bool battle::nextact(void)
{
	actturn++;
	int tem;
	char at;//�������O
	char run;//�k�]���O
	if (actturn > plyc + monc) 
	{
		turn++;
		actturn = 0;
	}
	while (true)
	{  
		for (int i = 0; i < plyc; i++)//���a����
		{
			showfield(20,15);
			if (actlist[i].live == 1)
			{
				p = static_cast<gp*>(actlist[i].instance);
				cout << "�A�{�b�ާ@��¾�~�O" << p->getName() << endl << endl;
				if (i == 0)//first round
				{
					cout << "�O�_�n�k�]?" << endl;
					cout << "�k�]�п�Jy,�԰��п�Jf" << endl;
					while (true)
					{
						cin >> run;
						if (run == 'y')
						{
							return 1;
						}
						else if (run == 'f')
						{
							break;
						}
						else if (run != 'y' || run != 'f')//���b
						{
							cout << "�ާ@���~�A�Э��s��J" << endl << endl;
							continue;
						}
					}
				}
				cout << "��ܧA�n�������Ǫ��s��:";
				cin >> tem;
				if (tem + plyc - 1 < 0 || tem + plyc - 1 > plyc + monc)//���b
				{
					cout << "�ާ@���~�A�Э��s��J" << endl<<endl;
					i--;
					continue;
				}
				m = static_cast<absmon*>(actlist[tem + plyc - 1].instance);
				cout << "��ܧA�n�������覡:" << endl << endl;
				cout << "a�����q�����As���S���ޯ�" << endl << endl;
				while (true) 
				{
					cin >> at;
					if (at == 'a')
					{
						p->attackTo(m);
						break;
					}
					else if (at == 's')
					{
						break;
					}
					else if (at != 'a' || at != 's')
					{
						cout << "�ާ@���~�A�Э��s��J" << endl << endl;
						continue;
					}
				}
			}
		}
		for (int i = plyc; i < plyc + monc; i++)//�Ǫ�����
		{
			showfield();
			if (actlist[i].live == 1)
			{
				p = static_cast<gp*>(actlist[i - plyc].instance);
				m = static_cast<absmon*>(actlist[i].instance);
				cout << m->name << "����" << i - plyc+1 << "������" << endl << endl;
				m->attackto(p);
			}
		}
	}
	return 1;
}
character battle::getcurrentactor(void) 
{
	return actlist[actturn];//actlist�ĴX�ӴN�N�����ӤH�Ω�
}
character*battle::getgp(void)
{
	character*tem = new character[plyc];
	for (int i = 0; i < plyc; i++) 
	{
		tem[i] = actlist[i];
	}
	return tem;
}
character*battle::getmon(void)
{
	character*tem = new character[monc];
	for (int i = plyc,j=0; i <plyc+monc;j++,i++)
	{
		tem[j] = actlist[i];
	}
	return tem;
}

