#include<iostream>
#include"magicpotion.h"
#include<string>


using namespace std;

