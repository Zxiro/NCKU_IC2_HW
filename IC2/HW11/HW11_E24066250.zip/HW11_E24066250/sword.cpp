#include<iostream>
#include"sword.h"
#include<string>


using namespace std;

