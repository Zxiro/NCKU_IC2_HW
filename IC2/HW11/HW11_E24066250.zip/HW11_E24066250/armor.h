#include<iostream>
using namespace std;
#ifndef armor_h
#define armor_h
class armor
{
public:
	const int defense_increment;
};
#endif

