#include<iostream>
#include<iomanip>
#include"Complex.h"
using namespace std;//���U�Ӷ}�l�w�qfunction
Complex::Complex(double A, double B )
{
	 real = A;
	 imag = B;
}
Complex Complex::add(Complex a) //�^�ǭȬ�complex
{
	
	double adddreal,adddimag;
	adddreal = a.real+real;
	adddimag = a.imag+imag;
	Complex addd = Complex(adddreal, adddimag);
	return addd;
}
Complex Complex::multiply(Complex b) 
{
	Complex muti(0, 0);
	muti.real = real * b.real - imag * b.imag;
	muti.imag = real * b.imag + imag * b.real;
	return muti;
}
Complex Complex::conjugate()
{
	Complex conj(0, 0);
	conj.real = real;
	conj.imag = -1*imag;
	return  conj;
}
Complex Complex::divide(Complex c)
{
	Complex divi(0, 0);
	divi.real = ((real*c.real) + (imag * c.imag)) / ((c.real*c.real) + (c.imag*c.imag));
	divi.imag = ((-1*real*c.imag)+imag*c.real)/ ((c.real*c.real) + (c.imag*c.imag));
	return divi;
}
void Complex::print() 
{
	if(imag<0){ cout << real << setw(2)  << imag << "i" << endl; }
	else if (imag > 0) { cout << real << setw(2) << "+" << imag << "i" << endl; }
}
Complex::~Complex() {}
int main(void)//test
{
	/*complex test(0.5, 0.5);
	complex ttt(5, 10);
	complex t();
	test.print();
	t = test.conjugate();
	t.print();
	t = test.divide(ttt);
	t.print();
	t = ttt.add(test);
	t.print();
	t = ttt.multiply(test);
	t.print();*/
	Complex a(0.6, 0.5); //0.6+0.5 i

	Complex b(0.4, 0.3); //0.4+0.3 i

	Complex c(0,0);

	a = a.conjugate(); //0.6 - 0.5 i
	a.print();
	c = a.add(b); // a+b
	c.print();
	c = a.divide(b);// a ���H b
	c.print();
	a.print();//�L�X 0.6+0.5 i//���ӬO0.6-0.5i
	system("pause");
}