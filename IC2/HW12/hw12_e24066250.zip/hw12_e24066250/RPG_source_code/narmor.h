#include<iostream>
#include"armor.h"
using namespace std;
class  narmor :public armor
{
public:
	narmor();
};