#include<iostream>
#include<vector>
#include<fstream>
using namespace std;
#ifndef maze_h
#define maze_h
class maze
{
public:
	maze();//consturctor
	void setmap(string);
	vector<vector<int>>map;
	vector<vector<int>>data;
	vector<vector<int>>mon;
	void print();
	void test();
	string mapname;
	int getdata();
	int getmondata();
	int getpost_x();
	int getpost_y();
	int post_x;
	int post_y;
	int end = 0,poi=0;//�פ��ܼ�
private:

};
#endif