#include<iostream>
#include<string>
#include"armor.h"
using namespace std;
class karmor :public armor
{
public:
	karmor();
};