#include<iostream>
#include"item.h"
using namespace std;
#ifndef armor_h
#define armor_h
class armor:public item
{
public:
	virtual int returnstat();
	armor(int);
	int defense_increment;
};
#endif

