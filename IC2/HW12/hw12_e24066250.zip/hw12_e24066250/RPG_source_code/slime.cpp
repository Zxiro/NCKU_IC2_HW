#include<iostream>
#include<string>
#include<time.h>
#include<random>
#include"generalplayer.h"
#include"slime.h"
#include"item.h"
using namespace std;
slime::slime()
	:absmon("slime",10,5,5,50,50,40)
{
	ite->name = "�v�ܩi�H��";
	ite->description="�������ԧQ�~";
	ite->type='n';
	ite->sell=15;
	sethp(max_hp); 
	setmp(max_mp);
}
slime::~slime()
{
	count;
}
void slime::attackto(gp*p)
{
	srand(time(NULL));
	int dam;
	int a = (rand() % 3);
	switch (a)
	{
	case(0):
		dam = (attack - p->getDefense())*1.1;
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	case(1):
		dam = (attack - p->getDefense())*0.9;
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	case(2):
		dam = (attack - p->getDefense());
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	}
	if (dam >= 0)
	p->setHP(p->getHP() - dam);
	if (p->getHP() < 0)
	{
		cout << "���a���`" << endl << endl;
	}
}