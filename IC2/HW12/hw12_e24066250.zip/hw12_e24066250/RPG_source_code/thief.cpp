#include<iostream>
#include<math.h>
#include"generalplayer.h"
#include"thief.h"
#include<random>
#include<time.h>
using namespace std;
thief::thief()
{
	c = "thief";
	setLevel(1);
	setHP(100);
	setMP(120);
	setExp(0);
	setmoney(50);
	setName("anonymous");
};
thief::thief(int a)
{
	c = "thief";
	setLevel(a);
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setmoney(50);
	setName("anonymous");
	setExp(pow(10, log2(a - 1 + 1)));
};
thief::thief(int a, string b)
{
	c = "thief";
	setLevel(a);
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setmoney(50);
	setExp(pow(10, log2(a - 1 + 1)));
	setName(b);
};
thief::thief(const thief &f)
{
	c = "thief";
	setLevel(f.level);
	setHP(f.getHP());
	setMP(f.getMP());
	setExp(f.getExp());
	setAttr(f.level);
	setName(f.getName());
};
void thief::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void thief::setAttr(int a)
{
	if (a > 0)
	{
		max_hp = 120 + 20 * a;
		max_mp = 60 + 7 * a;
		max_exp = pow((log2(a + 1)), 2) * 50;
		attack = 50 + 8 * a;
		defense = 25 + 7 * a;
	}
}
void thief::setLevel(int a)
{
	if (a > 0)
	{
		level = a;
		setAttr(a);
	}
	else if (a <= 0) {
		level = 1; setAttr(1);
		cout << level;
	}
}
void thief::increaseExp(int a)
{
	setExp(getExp() + a);
	if (getExp() >= max_exp)
	{
		while (true)
		{
			if (getExp() >= max_exp)
				levelUp();
			else
				break;
		}
	}
}
void thief::skill()
{
	srand(time(NULL));
	int h = getHP();
	int m = getMP();
	int randmon = rand() % 5 + 1;
	if (m - level * 5 > 0)
	{
		m = m - level * 5;
		cout << "�ѵs����" << endl;
		cout << endl << "STEAL" << randmon << " GOLD" << endl;
		money = money + randmon;
		cout << endl << "NOW: " << money << " GOLD" << endl;
	}
	else
		cout << "�L�k�ϥ�" << endl;
}
