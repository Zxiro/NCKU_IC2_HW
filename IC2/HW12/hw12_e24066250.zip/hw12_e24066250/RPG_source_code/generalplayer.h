#include<iostream>
#include<string>
#include<vector>
#include"item.h"
using namespace std;
#ifndef generalplayer_h
#define generalplayer_h
class absmon;
class item;
class gp
{ 
public:
	//void gotoxyz(int,int);
	void setmoney(int);
	void showback();
	int getmoney()const;
	string serial()const;
	void unserial(string);
	bool putin(item*);
	bool equip(int);
	gp();
	gp(int);
	gp(int,string);//constructor with player name
	gp(const gp &); //copy constructor
	string getName()const;
	void setName(string);
	int getHP()const;
	void setHP(int);
	int getMP()const;
	void setMP(int);
	int getExp()const;
	void setExp(int);
	void setLevel(int);
	void attackTo(absmon*);
	virtual void setAttr(int);
	virtual void levelUp(void);
    virtual void skill();
	void increaseHP(int);
	void increaseMP(int);
	void increaseExp(int);
	void recoverHP(void); // hp = max_hp;
	void recoverMP(void); // mp = max_mp;
	int getAttack(void) const;
	int getlevel(void)const;
	int getDefense(void) const;
	int getMaxHP(void) const;
	int getMaxMP(void) const;
	int getmaxexp(void) const;
	int getitemnum();
	string c;
	int itemnum;
	vector<item*>backpack;
private:
	item* tempback;
	vector<gp*>gps;
	string name;
	int hp ; // >=0   <max
	int mp; // >=0  <max
	int exp;// >=0  <max

	int back_limit = 30;
protected:
	int money;
	int level; // >=0
	int max_hp; // automatically calculated, >=0
	int max_mp;// automatically calculated, >=0
	int max_exp;// automatically calculated, >=0
	int attack;// automatically calculated, >=0
	int defense; // automatically calculated, >=0

};
#endif 


