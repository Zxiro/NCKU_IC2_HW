#include<iostream>
#include"generalplayer.h"
#include"consumeable.h"
using namespace std;
#ifndef lifepotion_h
#define lifepotion_h
class lifepotion :public consume
{
public:
	lifepotion();
	virtual int returnstat();
};
#endif