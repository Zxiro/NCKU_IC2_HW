#include<iostream>
#include<string>
#include"generalplayer.h"
#include"absmon.h"
#include"item.h"
using namespace std;
#ifndef goblin_h
#define goblin_h
class goblin :public absmon
{
public:
	goblin();
	~goblin();
	virtual void attackto(gp*);
};
#endif
