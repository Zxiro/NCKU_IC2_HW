#include<iostream>
#include<string>
#include<random>
#include<time.h>
#include<windows.h>
#include"absmon.h"
#include"zombie.h"
#include"boss.h"
#include"goblin.h"
#include"slime.h"
#include"magi.h"
#include"knight.h"
#include"orc.h"
#include"generalplayer.h"
#include"battle.h"
#include"maze.h"
#include"thief.h"
#include<conio.h>
#include<iomanip>
/*#ifdef _DEBUG
#define DEBUG_CLIENTBLOCK   new( _CLIENT_BLOCK, __FILE__, __LINE__)
#endif
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif*/
using namespace std;
gp*p;
absmon*m;
void battle::setmon() 
{
	srand(time(NULL));
	monchance = rand() % 3 + 1;
	switch (monchance)
	{
	case(1):
	{	
		monc = 1;
		mons.push_back(new slime());
		break;
	}
	case(2):
	{	
		monc = 2;
	for (int k = 0; k < 2; k++)
	{
		randmon = rand() % 11;
		if (randmon % 2 == 1) 
		{
			mons.push_back(new zombie());
			continue;
		}
		if (randmon % 2 == 0) 
		{
			mons.push_back(new goblin());
			continue;
		}
	}
	break;
	}
	case(3):
	{	
	  monc = 3;
	  for (int k = 0; k < 3; k++)
	  {
		  randmon = rand() % 11+1;
		  if (randmon % 3 == 1)
		  {
			  mons.push_back(new zombie());
			  continue;
		  }
		  if (randmon % 3 == 0)
		  {
			  mons.push_back(new  goblin());
			  continue;
		  }
		  if (randmon % 3 == 2) 
		  {
			  mons.push_back(new slime());
			  continue;
		  }
		  if (randmon==11)
		  {
			  mons.push_back(new boss());
			  continue;
		  }
	  }
	  break;
	}
	}
	for (int i = plyc; i < plyc + monc; i++)
	{
		actlist[i].type = 'm';
		actlist[i].live = 1;
		actlist[i].instance = mons[i - plyc];
	}
	
	//_CrtDumpMemoryLeaks();
}

void battle::setteam() 
{
	gps.clear();
	int x = 15, y = 1,car;
	string name;
	while (true) 
	{
		gotoxy(0, 0);
		cout << "============================================"<<endl;
		gotoxy(0, 6);
		cout << "============================================";
		gotoxy(0, 1);
		cout << "          �п�J����ƶq �ܦh4��" << endl;
		cin >> plyc;
		if (plyc > 4 || plyc <= 0)
		{
			cout << "Out of range Try again" << endl << endl;
			continue;
		}
		else break;
		}
	system("cls");
	for (int i = 0; i < plyc; i++)//���a
		{
			gotoxy(x*( + 1) - 15, y - 1);
			cout << "============================================";
			gotoxy(x*(+1) - 15, y + 5);
			cout << "============================================" << endl;
			gotoxy(x*( + 1) - 15, y);
			cout << "          �п�ܲ�" << i + 1 << "�쨤�⪺¾�~: "<<endl<<"          1���k�v 2���M�h 3���b�~�H 4���s��"<<endl;
			while (true) 
			{
				cin >> car;
				if (car>4||car<=0||cin.fail())
				{
					cout << "�ާ@���~�A�Э��s��J" << endl << endl;
					cin.ignore();
					cin.clear();
					car = 0;
					continue;
				}
				else
				system("cls");
				break;
			}
			while (true)
			{
				gotoxy(x*(+1) - 15, y - 1);
				cout << "============================================";
				gotoxy(x*(+1) - 15, y + 5);
				cout << "============================================" << endl;
				gotoxy(x*(+1) - 15, y );
				cout << "          �п�J����W�r: ";
				cin >> name;
				if (car == 1)
				{
					gps.push_back(new magi(1, name));
					name.clear();
					break;
				}
				if (car == 2)
				{
					gps.push_back(new knight(1, name));
					name.clear();
					break;
				}
				if (car == 3)
				{
					gps.push_back(new orc(1, name ));
					name.clear();
					break;
				}
				if (car == 4)
				{
					gps.push_back(new thief(1, name));
					name.clear();
					break;
				}
			}
			system("cls");
		}
	_CrtDumpMemoryLeaks();
	}

battle::battle()
{
	setteam();
    actlist=new character[plyc + monc];//a+b��character
	for (int i = 0; i < plyc; i++)
	{
		actlist[i].type = 'p';
		actlist[i].live = 1;
		actlist[i].instance = gps[i];//�V�L�@�hpointer
	}
	//delete actlist;
}

void battle::move(maze& m) 
{
	while (true)
	{
		cout << setw(4) << "�w��Ө�: " << m.mapname << endl;
		cout << setw(4) << "�Шϥ�w,a,s,d��Ӿ��a�A������"<<endl;
		cout << setw(4) << "�Y�n�d�ݭI�]�п�Jb"<<endl;
		cout << setw(4) << "�Y�n�˳ƪ��~�п�Je";
		unsigned char key = _getch();//��J����
		if (key != 'w' && key != 'a' && key != 's' && key != 'd'&&key != 'b'&&key!='e')//���b
		{
			system("cls");
			m.print();
			continue;
		}
		switch (key)
		{
		case('w'):
		{
			if (m.mon[m.post_y - 1][m.post_x] == 5 || m.mon[m.post_y - 1][m.post_x] == 6)
			{
				system("cls");
				m.post_y = m.post_y - 1;
				break;
			}
			if (m.map[m.post_y - 1][m.post_x] == 500)
			{
				system("cls");
				m.mapname = "�@�l��";
				m.setmap("�s���.txt");
				m.post_y++;
			}
			if (m.map[m.post_y - 1][m.post_x] == 501)
			{
				system("cls");
				m.mapname = "�J�����O�L";
				m.setmap("�@�l�O�L.txt");
				m.post_y++;
			}
			if (m.map[m.post_y - 1][m.post_x] == 502)
			{
				system("cls");
				m.mapname = "�Z������";
				m.setmap("�Z������.txt");
				m.post_y++;

			}
			if (m.map[m.post_y - 1][m.post_x] == 503)
			{
				system("cls");
				m.mapname = "�ӱڱK��";
				m.setmap("�ӱڱK��.txt");
				m.post_y++;
			}
			if (m.map[m.post_y - 1][m.post_x] == 504)
			{
				system("cls");
				m.mapname = "�R�B����e���f";
				m.setmap("�R�B����e���f.txt");
				m.post_y++;
			}
			if (m.map[m.post_y - 1][m.post_x] == 505)
			{
				system("cls");
				m.mapname = "���Z�E��";
				m.setmap("���Z�E��.txt");
				m.post_y++;
			}
			else if (m.map[m.post_y - 1][m.post_x] != 1)
			{
				system("cls");
				m.post_y = m.post_y - 1;
				m.print();
				cout << "Player_postion:(" << m.post_x << "," << m.post_y << ")" << endl;
				continue;
				//break;
			}
			system("cls");
			m.print();
			continue;
			//break;
		}
		case('a'):
		{
			if (m.mon[m.post_y][m.post_x - 1] == 5 || m.mon[m.post_y][m.post_x - 1] == 6)
			{
				system("cls");
				m.post_x = m.post_x - 1;
				break;
			}
			if (m.map[m.post_y][m.post_x - 1] == 500)
			{
				system("cls");
				m.mapname = "�@�l��";
				m.setmap("�s���.txt");
				m.post_x++;
			}
			if (m.map[m.post_y][m.post_x - 1] == 501)
			{
				system("cls");
				m.mapname = "�J�����O�L";
				m.setmap("�@�l�O�L.txt");
				m.post_x++;
			}
			if (m.map[m.post_y][m.post_x - 1] == 502)
			{
				system("cls");
				m.mapname = "�Z������";
				m.setmap("�Z������.txt");
				m.post_x++;
			}
			if (m.map[m.post_y][m.post_x - 1] == 503)
			{
				system("cls");
				m.mapname = "�ӱڱK��";
				m.setmap("�ӱڱK��.txt");
				m.post_x++;
			}
			if (m.map[m.post_y][m.post_x - 1] == 504)
			{
				system("cls");
				m.mapname = "�R�B����e���f";
				m.setmap("�R�B����e���f.txt");
				m.post_x++;
			}
			if (m.map[m.post_y][m.post_x - 1] == 505)
			{
				system("cls");
				m.mapname = "���Z�E��";
				m.setmap("���Z�E��.txt");
				m.post_x++;
			}
			else if (m.map[m.post_y][m.post_x - 1] != 1)
			{
				system("cls");
				m.post_x = m.post_x - 1;
				m.print();
				cout << "Player_postion:(" << m.post_x << "," << m.post_y << ")" << endl;
				continue;
				// break;
			}
			system("cls");
			m.print();
			continue;
			//break;
		}
		case('s'):
		{
			if (m.mon[m.post_y + 1][m.post_x] == 5 || m.mon[m.post_y + 1][m.post_x] == 6)
			{
				system("cls");
				m.post_y = m.post_y + 1;
				break;
			}
			if (m.map[m.post_y + 1][m.post_x] == 500)
			{
				system("cls");
				m.mapname = "�@�l��";
				m.setmap("�s���.txt");
				m.post_y--;
			}
			if (m.map[m.post_y + 1][m.post_x] == 501)
			{
				system("cls");
				m.mapname = "�J�����O�L";
				m.setmap("�@�l�O�L.txt");
				m.post_y--;
			}
			if (m.map[m.post_y + 1][m.post_x] == 502)
			{
				system("cls");
				m.mapname = "�Z������";
				m.setmap("�Z������.txt");
				m.post_y--;
			}
			if (m.map[m.post_y + 1][m.post_x] == 503)
			{
				system("cls");;
				m.mapname = "�ӱڱK��";
				m.setmap("�ӱڱK��.txt");
				m.post_y--;
			}
			if (m.map[m.post_y + 1][m.post_x] == 504)
			{
				system("cls");
				m.mapname = "�R�B����e���f";
				m.setmap("�R�B����e���f.txt");
				m.post_y--;
			}
			if (m.map[m.post_y + 1][m.post_x] == 505)
			{
				system("cls");
				m.mapname = "���Z�E��";
				m.setmap("���Z�E��.txt");
				m.post_y--;
			}
			else if (m.map[m.post_y + 1][m.post_x] != 1)
			{
				system("cls");
				m.post_y = m.post_y + 1;
				m.print();
				cout << "Player_postion:(" << m.post_x << "," << m.post_y << ")" << endl;
				continue;
				//break;
			}
			system("cls");
			m.print();
			continue;
			//break;
		}
		case('d'):
		{
			if (m.mon[m.post_y][m.post_x + 1] == 5 || m.mon[m.post_y][m.post_x + 1] == 6)
			{
				system("cls");
				m.post_x = m.post_x + 1;
				break;
			}
			if (m.map[m.post_y][m.post_x + 1] == 500)
			{
				system("cls");
				m.mapname = "�@�l��";
				m.setmap("�s���.txt");
				m.post_x--;
			}
			if (m.map[m.post_y][m.post_x + 1] == 501)
			{
				system("cls");
				m.mapname = "�J�����O�L";
				m.setmap("�@�l�O�L.txt");
				m.post_x--;
			}
			if (m.map[m.post_y][m.post_x + 1] == 502)
			{
				system("cls");
				m.mapname = "�Z������";
				m.setmap("�Z������.txt");
				m.post_x--;
			}
			if (m.map[m.post_y][m.post_x + 1] == 503)
			{
				system("cls");
				m.mapname = "�ӱڱK��";
				m.setmap("�ӱڱK��.txt");
				m.post_x--;
			}
			if (m.map[m.post_y][m.post_x + 1] == 504)
			{
				system("cls");
				m.mapname = "�R�B����e���f";
				m.setmap("�R�B����e���f.txt");
				m.post_x--;
			}
			if (m.map[m.post_y][m.post_x + 1] == 505)
			{
				system("cls");
				m.mapname = "���Z�E��";
				m.setmap("���Z�E��.txt");
				m.post_x--;
			}
			else if (m.map[m.post_y][m.post_x + 1] != 1)
			{
				system("cls");
				m.post_x = m.post_x + 1;
				m.print();
				cout << "Player_postion:(" << m.post_x << "," << m.post_y << ")" << endl;
				continue;
				//break;
			}
			system("cls");
			m.print();
			continue;
			//break;
		}
		case('b'):
		{	int ckb;
			while (true) 
			{
				system("cls");
				cout << "�A�Q�d�ݽ֪��I�]?�п�J�s��" << endl;
				cout << "�Y�Q���} �п�J0" << endl;
				for (int i = 0; i < plyc; i++)//���a
				{
					if (actlist[i].live == 1)
					{
						p = static_cast<gp*>(actlist[i].instance);
						gotoxy(15 * (i + 1) - 15, 3);
						cout << "==============";
						gotoxy(15 * (i + 1) - 15, 4);
						cout << "��" << i + 1 << "��";
						gotoxy(15 * (i + 1) - 15, 5);
						cout << "¾�~: " << p->c;
						gotoxy(15 * (i + 1) - 15, 6);
						cout << "NAME: " << p->getName();
						gotoxy(15 * (i + 1) - 15, 7);
						cout << "==============" << endl;
					}
				}
				cin >> ckb;
				if (ckb < 0 || ckb > gps.size())
				{
					cout << "��J���~,�Э��s��J" << endl;
					system("pause");
					continue;
				}
				else if (ckb == 0)
				{
					break;
				}
				cout << gps[ckb - 1]->getitemnum() << endl;
				system("pause");
				if (gps[ckb - 1]->getitemnum() == 0)
				{
					cout << "�I�]�O�Ū�!" << endl;
					system("pause");
					system("cls");
					break;
				}
				else
					system("cls");
					gotoxy(0, 0);
					cout << "�A���b�d�ݲ�" << ckb << "�쪱�a���I�]" << endl;
				    gps[ckb-1]->showback();
					system("pause");
					system("cls");
					break;
			}
			break;
		}
		case('e'): 
		{	
			system("cls");
			int eq,cheq;
		gotoxy(0, 0);
		cout << "==============" << endl;
		gotoxy(0, 1);
		cout << "�A�Q���ָ˳�?" << endl;
		gotoxy(0, 2);
		cout << "�Y�Q���} �п�J0" << endl;
		for (int i = 0; i < plyc; i++)//���a
		{
			if (actlist[i].live == 1)
			{
				p = static_cast<gp*>(actlist[i].instance);
				gotoxy(15*(i + 1) - 15, 3);
				cout << "==============";
				gotoxy(15*(i + 1) - 15, 4);
				cout << "��" << i + 1 << "��";
				gotoxy(15 * (i + 1) - 15, 5);
				cout << "¾�~: " << p->c;
				gotoxy(15*(i + 1) - 15, 6);
				cout << "NAME: " << p->getName();
				gotoxy(15 * (i + 1) - 15, 7);
				cout << "=============="<<endl;
			}
		}
		while (true)
		{
			cin >> eq;//�˳ƪ��H��
			if (eq < 0 || eq > gps.size())
			{
				cout << "��J���~,�Э��s��J" << endl;
				system("pause");
				continue;
			}
			else 
				break;
		}
		while (true)
		{
			if (eq == 0)
			{
				system("cls");
				break;
			}
			system("cls");
			gps[eq - 1]->showback();
			if (gps[eq - 1]->getitemnum() == 0)
			{
				cout << "�I�]�O�Ū�!" << endl;
				system("pause");
				system("cls");
				break;
			}
			gotoxy(0, 9);
			cout << "�Q�˳ƭ������~?" << endl;
			cin >> cheq;
			if (cheq < 0 || cheq > gps[eq-1]->getitemnum())
			{
				cout << "��J���~,�Э��s��J" << endl;
				system("pause");
				continue;
			}
			else
				gps[eq-1]->equip(cheq-1);
			gps[eq - 1]->showback();
				break;
		}
		}
		}
		break;
	}
}

void battle::showfield(int x,int y)
{
	for (int i = 0; i < plyc; i++)//���a
	{
		if (actlist[i].live == 1)
		{
			p = static_cast<gp*>(actlist[i].instance);
			gotoxy(x*(i + 1) - 15, y-1);
			cout << "==============" ;
			gotoxy(x*(i + 1) - 15, y);
			cout << "¾�~: " <<p->c;
			gotoxy(x*(i + 1) - 15, y + 1);
			cout << "NAME: " << p->getName();
			gotoxy(x*(i + 1) - 15, y + 2);
			cout<< "HP: " << p->getHP();
			gotoxy(x*(i + 1) - 15, y + 3);
			cout << "MP: "<< p->getMP();
			gotoxy(x*(i + 1) - 15, y + 4);
			cout << "DEF: " << p->getDefense();
			gotoxy(x*(i + 1) - 15, y + 5);
			cout << "ATT: " << p->getAttack();
			gotoxy(x*(i + 1) - 15, y + 6);
			cout << "Money: " << p->getmoney();
			gotoxy(x*(i + 1) - 15, y + 7);
			cout << "=============="<<endl ;
		}
		else if (actlist[i].live == 0)
		{
			p = static_cast<gp*>(actlist[i].instance);
			gotoxy(x*(i + 1) - 15, y - 1);
			cout << "=============="<<endl;
			gotoxy(x*(i + 1) - 15, y);
			cout << "�s��: " << i + 1;
			gotoxy(x*(i + 1) - 15, y + 1);
			cout << "NAME: " << p->getName();
			gotoxy(x*(i + 1)-15, y + 2);
			cout << "���A: ���`";
			gotoxy(x*(i + 1)-15, y + 3);
			cout << "==============" << endl;
		}
	}
	for (int i = plyc; i < plyc + monc; i++)//�Ǫ�
	{
		if (actlist[i].live == 1)
		{
			m = static_cast<absmon*>(actlist[i].instance);
			gotoxy(x* (i + 1), y-1);
			cout << "==============" ;
			gotoxy(x*(i + 1), y);
			cout << "�s��: " << i - plyc + 1;
			gotoxy(x* (i + 1), y+1);
			cout << "NAME: " <<m->name;
			gotoxy(x* (i + 1), y+2);
			cout << "HP: " << m->gethp();
			gotoxy(x* (i + 1), y+3);
			cout << "MP: " << m->getmp();
			gotoxy(x* (i + 1), y+4);
			cout << "DEF: " << m->getdef();
			gotoxy(x* (i + 1), y+5);
			cout << "ATT: " << m->attack;
			gotoxy(x* (i + 1), y+6);
			cout << "=============="<<endl ;
		}
		else if (actlist[i].live == 0)
		{
			m = static_cast<absmon*>(actlist[i].instance);
			gotoxy(x*(i + 1) , y - 1);
			cout << "=============="<<endl;
			gotoxy(x*(i + 1) , y);
			cout << "�s��: " << i-plyc + 1;
			gotoxy(x*(i + 1), y + 1);
			cout << "NAME: " << m->name ;
			gotoxy(x*(i + 1), y + 2);
			cout << "���A: ���`";
			gotoxy(x*(i + 1), y + 3);
			cout << "=============="<<endl;
		}
	}
}

bool battle::nextact(void)
{
	setmon();
	int tem;
	char at,run;
	while (true)
	{
		system("cls");
		showfield(15, 1);
		for (int i = 0; i < plyc; i++)//���a����
		{
			for (int i = 0; i < plyc; i++)//�˴����`
			{
				p = static_cast<gp*>(actlist[i].instance);
				if (p->getHP() <= 0)
				{
					actlist[i].live = 0;
				}
			}
			for (int i = plyc; i < plyc + monc; i++)//�˴����`
			{
				m = static_cast<absmon*>(actlist[i].instance);
				if (m->gethp() <= 0)
				{
					actlist[i].live = 0;
				}
			}

			if (actlist[i].live == 1)//���s�@��
			{   
				if (i == 0)//first round
				{
					gotoxy(1, 10);
					cout << endl;
					cout << "�O�_�n�k�]?" << endl<<endl;
					cout << "�k�]�п�Jy,�԰��п�Jf" << endl;
					while (true)
					{
						cin >> run;
						if (run == 'y')
						{
							system("cls");
							return 1;
						}
						else if (run == 'f')
						{
							break;
						}
						else if (run != 'y' || run != 'f')
						{
							cout << "�ާ@���~�A�Э��s��J" << endl << endl;
							continue;
						}
					}
				}
				system("cls");
				showfield(15,1);
				p = static_cast<gp*>(actlist[i].instance);
				gotoxy(1, 10);
				cout <<endl<< "�A�{�b�ާ@���H���O" << p->getName() << endl << endl;
				
				cout <<endl<< "��ܧA�n�������Ǫ��s��:";

				while (true)
				{
					cin >> tem;
				    if (cin.fail())
					{
						cout<<endl << "��J���~ �п�J�s��!" << endl << endl;
						cin.clear();
						cin.ignore();
						continue;
					}
					else if (tem + plyc - 1 < 0 || tem + plyc - 1 >= plyc + monc )//���b
					{
						cout << "��J���~�A�Э��s��J!" << endl << endl;
						continue;
					}
					else if (actlist[tem + plyc - 1].live == 0)
					{
						cout << "�Ǫ��w���` ���@��" << endl << endl;
						continue;
					}
					else 
						break;
				}

				m = static_cast<absmon*>(actlist[tem + plyc - 1].instance);

				cout<<endl << "��ܧA�n�������覡:" << endl << endl;
				 
				cout << "a �����q�����As ���S���ޯ�" << endl << endl;

				while (true) 
				{
					cin >> at;
					if (at == 'a')
					{
						p->attackTo(m);
						break;
					}
					else if (at == 's')
					{
						p->skill();
						break;
					}
					else if (at != 'a' || at != 's')
					{
						cout << "�ާ@���~�A�Э��s��J" << endl << endl;
						cin.ignore();
						cin.clear();
						continue;
					}
				}//���b
			}
			system("pause");
			for (int i = 0; i < plyc; i++)//�˴����`
			{
				p = static_cast<gp*>(actlist[i].instance);
				if (p->getHP() <= 0)
				{
					actlist[i].live = 0;
				}
				if (getgpcount(1) == 0)
				{
					cout << "���aGG" << endl;
					system("pause");
					system("cls");
					return 1;
				}
			}

			for (int i = plyc; i < plyc + monc; i++)//�˴����`
			{
				int alldieornot = 0;
				m = static_cast<absmon*>(actlist[i].instance);
				if (m->gethp() <= 0)
				{
					actlist[i].live = 0;
				}
			}
			if (getmoncount(1) == 0)
			{
				cout << "���a���!!" << endl;
				system("pause");
				system("cls");
				return 1;
			}
		}
		for (int i =plyc; i < plyc+monc ; i++)//�Ǫ�����
		{
			int attt=0;
			if (actlist[i].live == 1)
			{
				m = static_cast<absmon*>(actlist[i].instance);
				while (true) 
				{
					int attt = rand() % plyc;
					p = static_cast<gp*>(actlist[attt].instance);
					if (p->getHP() > 0) { break; }
					else continue;
				}
				cout << m->name << "����" << attt + 1 << "������" << endl << endl;
				m->attackto(p);
			}
		}
		_CrtDumpMemoryLeaks();
		system("pause");
	}
	return 1;
}


















character battle::getcurrentactor(void) 
{
	return actlist[actturn];//actlist�ĴX�ӴN�N�����ӤH�Ω�
}
character*battle::getgp(void)
{
	character*tem = new character[plyc];
	for (int i = 0; i < plyc; i++) 
	{
		tem[i] = actlist[i];
	}
	return tem;
}
character*battle::getmon(void)
{
	character*tem = new character[monc];
	for (int i = plyc,j=0; i <plyc+monc;j++,i++)
	{
		tem[j] = actlist[i];
	}
	return tem;
}
int battle::getturn(void)const
{
	return turn;
}
int battle::getlimturn(void)const
{
	return limturn;
}
int battle::getgpcount(void)const
{
	return plyc;
}
int battle::getmoncount(bool life)const
{
	int tempc = 0;
	if (life == 1)
	{
		for (int i = plyc; i < monc + plyc; i++)
		{
			if (actlist[i].live == 1)
			{
				tempc++;
			}
		}
		return tempc;
	}
	else if (life == 0)
	{
		return monc;
	}
}
int battle::getmoncount(void)const
{
	return monc;
}
int battle::getgpcount(bool life)const
{
	int tempc = 0;
	if (life == 1)
	{
		for (int i = 0; i <= plyc - 1; i++)
		{
			if (actlist[i].live == 1)
			{
				tempc++;
			}
		}
		return tempc;
	}
	else if (life == 0)
	{
		return plyc;
	}
}
void battle::gotoxy(int xpos, int ypos)
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = xpos; scrn.Y = ypos;
	SetConsoleCursorPosition(hOuput, scrn);
}