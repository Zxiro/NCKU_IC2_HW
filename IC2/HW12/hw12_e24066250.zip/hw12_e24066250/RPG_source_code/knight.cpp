#include<iostream>
#include<math.h>
#include"generalplayer.h"
#include"knight.h"
using namespace std;
knight::knight()
{
	c = "knight";
	level = 1;
	setAttr(1);
	setHP(180);
	setMP(35);
	setExp(0);
	setmoney(50);
	setName("anonymous");
};
knight::knight(int a)
{
	c = "knight";
	setLevel(a);
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setmoney(50);
	setName("anonymous");
	setExp(pow(10, log2(a - 1 + 1)));
};
knight::knight(int a, string b)
{
	c = "knight";
	setLevel(a);
	setAttr(a);
	setHP(max_hp);
	setMP(max_mp);
	setmoney(50);
	setExp(pow(10, log2(a - 1 + 1)));
	setName(b);
};
knight::knight(const knight&f)
{
	c = "knight";
	setLevel(f.level);
	setHP(f.getHP());
	setMP(f.getMP());
	setExp(f.getExp());
	setAttr(f.level);
	setName(f.getName());
};
void knight::levelUp()
{
	level++;
	setAttr(level);
	recoverHP();
	recoverMP();
}
void knight::setAttr(int a)
{
	if (a > 0)
	{
		max_hp = 180 + 30 * a;
		max_mp = 35 + 5 * a;
		max_exp = pow((log2(a + 1)), 2) * 50;
		attack = 50 + 8 * a;
		defense = 40 + 5 * a;
	}
}
void knight::increaseExp(int a)
{
	setExp(getExp() + a);
	if (getExp() >= max_exp)
	{
		while (true)
		{
			if (getExp() >= max_exp)
				levelUp();
			else
				break;
		}
	}
}
void knight::setLevel(int a)
{
	if (a > 0)
	{
		level = a;
		setAttr(a);
	}
	else if (a <= 0) {
		level = 1; setAttr(1);
		cout << level;
	}
}
void knight::skill()
{
	int h = getHP();
	int m = getMP();
	int l = getlevel();
	if (m - l * 5 > 0)
	{
		m=m - l * 5;
		h=h + l * 10;
		if (h>= max_hp)
		{
			cout << "�ϥί��t���[�@" << endl;
		    setMP(m);
			cout << endl << "HEAL: " << l * 10 << " HP" << endl;
			setHP(max_hp);
			cout << endl << "NOW: " << getHP() << " HP" << endl;
			//system("pause");
		}
		else if (h < max_hp) 
		{
			cout << "�ϥί��t���[�@" << endl;
			setMP(m);
			cout << endl << "HEAL: " << l * 10 << " HP" << endl;
			setHP(h);
			cout << endl << "NOW: " << getHP() << " HP" << endl;
			//system("pause");
		}
	}
	
}