#include<iostream>
#include"consumeable.h"
#include"weapon.h"
using namespace std;