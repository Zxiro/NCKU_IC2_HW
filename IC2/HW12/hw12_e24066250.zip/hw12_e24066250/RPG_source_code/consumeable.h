#include<iostream>
#include"item.h"
#include"generalplayer.h"
using namespace std;
#ifndef consume_h
#define consume_h
class consume:public item
{
public:
};
#endif