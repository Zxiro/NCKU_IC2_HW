#include<iostream>
#include<string>
using namespace std;
#ifndef item_h
#define item_h
class item
{
public:
	virtual int returnstat();
	int level_required;//�ݭn����
	string name;
	string effect;
	string description;
	char type;
	int cost;
	int sell;
	bool eqornot;
};
#endif