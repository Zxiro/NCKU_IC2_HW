#include<iostream>
#include"item.h"
using namespace std;
#ifndef weapon_h
#define weapon_h
class weapon:public item
{
public:
	virtual int returnstat();
	weapon(int);
	int attack_increment;//�����O�W�[
private:
};
#endif
