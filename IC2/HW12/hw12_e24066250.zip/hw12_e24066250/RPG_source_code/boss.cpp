#include<iostream>
#include<string>
#include"generalplayer.h"
#include"boss.h"
#include<time.h>
#include"goblin.h"
#include"zombie.h"
using namespace std;

boss::boss()
	:absmon("Ganon",120,100,42,250,100,125)
{

	ite->name = "�Y�ت����a";
	ite->description = "�������ԧQ�~";
	ite->type = 'n';
	ite->sell = 200;
	sethp(max_hp); setmp(max_mp);
}
boss::~boss()
{
	count--;
}
void boss::attackto(gp*p) 
{if(gethp()<max_hp)
	sethp(gethp()*1.1);
if (getmp() < max_mp)
	setmp(getmp()*1.05);

srand(time(NULL));
int dam;
int a = (rand() % 2), b = (rand() % 3);
switch (a)
{
case(0):
	switch (b)
	{
	case(0):
		dam = (attack - p->getDefense())*1.1;
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	case(1):
		dam = (attack - p->getDefense())*0.9;
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	case(2):
		dam = (attack - p->getDefense());
		if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
		cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
		break;
	}
	break;
case(1):
	dam = (attack * 4 - p->getDefense());
	if (dam <= 0) { cout << "Does No Damage" << endl << endl; break; }
	cout << "�y��" << dam << "�I�ˮ`" << endl << endl;
	setmp(getmp() - 10);
	break;
}
if(dam>=0)
p->setHP(p->getHP() - dam);
if (p->getHP() < 0)
{
	cout << "���a���`" << endl << endl;
}
}