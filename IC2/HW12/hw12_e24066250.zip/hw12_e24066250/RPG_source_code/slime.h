#include<iostream>
#include<string>
#include"generalplayer.h"
#include"absmon.h"
#include"item.h"
using namespace std;
#ifndef slime_h
#define slime_h
class slime :public absmon
{
public:
	slime();
	~slime();
	virtual void attackto(gp*);
};
#endif