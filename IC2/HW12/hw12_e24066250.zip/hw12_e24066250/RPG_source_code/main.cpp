#include<iostream>
#include<math.h>
#include<iomanip>
#include<time.h>
#include<windows.h>
#include<random>
#include<sstream>
#include<fstream>
#include<vector>
#include"event.h"
#include"item.h"
#include"consumeable.h"
#include"armor.h";
#include"weapon.h"
#include"generalplayer.h"
#include"absmon.h"
#include"battle.h"
#include"boss.h"
#include"maze.h"
#include"magicpotion.h"
#include"shield.h"
#include"spikeglove.h"
#include"k-armor.h"
#include"sword.h"
#include"tunic.h"
#include"axe.h"
#include"narmor.h"
#include"knife.h"
#include"lifepotion.h"
#include"magicpotion.h"
using namespace std;
maze g;
maze *ptr = &g;
battle b;
axe ax;axe *axptr = &ax; sword s; sword *sptr = &s; spikeglove sg; spikeglove *sgptr = &sg; knife kn; knife*knptr = &kn;
karmor ka; karmor *kaptr = &ka; tunic tu; tunic *tuptr = &tu; shield sh; shield *shptr = &sh; narmor na; narmor*naptr = &na;
lifepotion life; lifepotion*lifeptr = &life; magicpotion magi; magicpotion*magiptr = &magi;
event ev1(1); event*ev1ptr = &ev1; event ev2(2); event*ev2ptr = &ev2; event ev3(3); event*ev3ptr = &ev3;
void bussinessman();
void gotovxy(int,int);
int ckbag,eventnumber=1;
int main(void)
{
	gotovxy(30, 0);
	cout << "�ܤ[�H�e�����Ծ|����A�������ǡA�H���w�~�ַ~"<<endl<<endl;
	Sleep(1000);
	gotovxy(30, 3);
	cout << "���]���[�A�X�{�ܨ��F�ӫǪ��_��-�X�]���C!" << endl << endl;
	Sleep(1000);
	gotovxy(30, 6);
	cout << "�]���ݭn�A�̭^�i���i�̲ն��M��X��" << endl << endl;
	Sleep(1000);
	gotovxy(30, 9);
	cout << "���n�S�ݡA���W�X�o�a!" << endl << endl;
	Sleep(1000);
	system("pause");
	system("cls");
	while (true)
	{
		b.move(g);
		if (ptr->getmondata() == 5)
		{
			b.gotoxy(55, 13);
			cout << "�i�J�԰�!!" << endl;
			system("pause");
			int temp = b.nextact(g);
			if (temp == 0) 
			{
				system("cls");
				b.gotoxy(30, 10);
				cout << "------------------------GAME OVER------------------------";
				system("pause");
				break;
			}
		}
		else if (ptr->getmondata() == 6)
		{
			bussinessman();
			system("pause");
			system("cls");
		}
		else if (ptr->getmondata() == 8)
		{
			if (b.eventlist.empty() == 1 && eventnumber == 1)
			{
				b.eventlist.push_back(ev1ptr);
			}
			else if (b.eventlist.empty() == 1 && eventnumber == 2)
			{
				b.eventlist.push_back(ev2ptr);
			}
			switch (eventnumber)
			{
			case(1):
				for (int k = 0; k < b.getgpcount(); k++)
				{
					int tempw = 0, tempa = 0;
					for (int i = 0; i < b.gps[k]->getitemnum(); i++)
					{
						if (b.gps[k]->backpack[i]->type == 'w')
						{
							tempw = 1;
						}
						if (b.gps[k]->backpack[i]->type == 'a')
						{
							tempa = 1;
						}
					}
					if (tempw + tempa == 2)
					{
						b.eventlist[0]->state = 2;
					}
				}
				switch (b.eventlist[0]->state)
				{
				case(0):
				{
					string con1;
					con1 = "�w��! �ڭ̤��V���ߪ��i��";
					for (int i = 0; i < con1.size(); i++)
					{

						cout << con1[i]; Sleep(100);
					}
					system("cls");
					con1 = "�b�e���Q���]�����e�A�Ʊ�A�৹���X��²�檺����";
					for (int i = 0; i < con1.size(); i++)
					{

						cout << con1[i]; Sleep(100);
					}
					system("cls");
					con1 = "�w�T�O�A�֦��ڭ̻ݭn������";
					for (int i = 0; i < con1.size(); i++)
					{

						cout << con1[i]; Sleep(100);
					}
					cout << endl;
					system("pause");
					system("cls");
					string con2;
					con2 = "�Ĥ@�ӥ��ȴN�O�ΧA���W�����ʶR�@�󨾨�P�@��Z��";
					for (int i = 0; i < con2.size(); i++)
					{

						cout << con2[i]; Sleep(100);
					}
					system("cls");
					con2 = "�ڷ|���A���y��";
					for (int i = 0; i < con2.size(); i++)
					{

						cout << con2[i]; Sleep(100);
					}
					system("pause");
					system("cls");
					cout << "�����o���ȶ�?" << endl;
					cout << "������J y �ڵ���J n" << endl;
					while (true)
					{
						char choice;
						cin >> choice;
						if (choice == 'y')
						{
							system("cls");
							b.eventlist[0]->state = 1;
							break;
						}
						else if (choice == 'n')
						{
							system("cls");
							break;
						}
						else if (choice != 'y' || choice != 'n')
						{
							cout << "�ާ@���~�A�Э��s��J" << endl << endl;
							continue;
						}
					}
					break;
				}
				case(1):
				{
					string con2;
					con2 = "�䤣��ө���??";
					for (int i = 0; i < con2.size(); i++)
					{
						cout << con2[i]; Sleep(100);
					}system("cls");
					con2 = "�ө��b�a�ϤW�N�Хܵ۰�";
					for (int i = 0; i < con2.size(); i++)
					{
						cout << con2[i]; Sleep(100);
					}system("cls");
					con2 = "�֥h�����a!";
					for (int i = 0; i < con2.size(); i++)
					{

						cout << con2[i]; Sleep(100);
					}
					system("pause");
					system("cls");
					break;
				}
				case(2):
				{
					string con2;
					con2 = "���ߧA�̳q�L����!";
					for (int i = 0; i < con2.size(); i++)
					{
						cout << con2[i]; Sleep(100);
					}
					system("cls");
					con2 = "�N�����x�T���K�K�{�P�A�̤F";
					for (int i = 0; i < con2.size(); i++)
					{
						cout << con2[i]; Sleep(100);
					}
					system("cls");
					con2 = "�o�O�����n�����y";
					for (int i = 0; i < con2.size(); i++)
					{
						cout << con2[i]; Sleep(100);
					}
					for (int i = 0; i < b.getgpcount(); i++)
					{
						b.gps[i]->setmoney(b.gps[i]->getmoney() + 300);
					}
					cout << endl << "��o300 GOLD!!" << endl;
					eventnumber++;
					system("pause");
					con2 = "���A�ǳƦn�U�ӥ��Ȫ��� �N�ӧ�ڧa";
					for (int i = 0; i < con2.size(); i++)
					{
						cout << con2[i]; Sleep(100);
					}
					b.eventlist.clear();
					system("pause");
					system("cls");
				}
				}
				break;
			case(2):
				if (b.eventlist[0]->killcount >= 10)
				{
					b.eventlist[0]->state = 2;
				}
				switch (b.eventlist[0]->state)
				{
				case(0):
				{
					string con1;
					con1 = "�ǳƦn�U�ӬD�ԤF��?";
					for (int i = 0; i < con1.size(); i++)
					{

						cout << con1[i]; Sleep(100);
					}
					system("cls");
					con1 = "�ܦn �U�ӬD�ԴN�O�h��10���b�~���v�h���Ǫ�";
					for (int i = 0; i < con1.size(); i++)
					{
						cout << con1[i]; Sleep(100);
					}
					system("pause");
					system("cls");
					cout << "�����o���ȶ�?" << endl;
					cout << "������J y �ڵ���J n" << endl;
					while (true)
					{
						char choice;
						cin >> choice;
						if (choice == 'y')
						{
							system("cls");
							b.eventlist[0]->state = 1;
							break;
						}
						else if (choice == 'n')
						{
							system("cls");
							break;
						}
						else if (choice != 'y' || choice != 'n')
						{
							cout << "�ާ@���~�A�Э��s��J" << endl << endl;
							continue;
						}
						break;
					}
					break;
				}
				case(1):
				{	string con1;
				con1 = "�ѰO���ȤF��?";
				for (int i = 0; i < con1.size(); i++)
				{
					cout << con1[i]; Sleep(100);
				}
				system("cls");
				con1 = "�U�ӬD�ԴN�O�h��10���b�~���v�h���Ǫ�";
				for (int i = 0; i < con1.size(); i++)
				{

					cout << con1[i]; Sleep(100);
				}system("cls");
				con1 = "���֥X�o�a!";
				for (int i = 0; i < con1.size(); i++)
				{
					cout << con1[i]; Sleep(100);
				}
				system("pause");
				system("cls");
				break;
				}
				case(2):
				{	string con2;
				con2 = "���o�ܦn!! �p�G�M�O���Ծ|���̫�Ʊ�";
				for (int i = 0; i < con2.size(); i++)
				{
					cout << con2[i]; Sleep(100);
				}
				system("cls");
				con2 = "�����ڪ����֧a";
				for (int i = 0; i < con2.size(); i++)
				{
					cout << con2[i]; Sleep(100);
				}
				system("cls");
				for (int i = 0; i < b.getgpcount(); i++)
				{
					b.gps[i]->setLevel(b.gps[i]->getlevel() + 5);
				}
				cout << "�Ҧ��H�����ɤF����!!!" << endl;
				system("pause");
				system("cls");
				con2 = "�o�O�̫᪺���ȤF,�֥h���Ѥj�]���a!";
				for (int i = 0; i < con2.size(); i++)
				{
					cout << con2[i]; Sleep(100);
				}
				b.eventlist.clear();
				b.eventlist.push_back(ev3ptr);
				system("cls");
				system("pause");
				}
				}
				break;
			case(3):
				cout << "�֥h�Q��j�]���a" << endl;
				system("pause");
				system("cls");
			}
		}
		else if (ptr->getmondata() == 10)
		{
			b.gotoxy(55, 13);
			cout << "�i�J�԰�!!" << endl;
			system("pause");
			int temp = b.nextact(g);
			if (temp == 0)
			{
				system("cls");
				b.gotoxy(30, 10);
				cout << "------------------------GAME OVER------------------------";
				system("pause");
				break;
			}
			else if (temp == 1)
			{
				system("cls");
				b.gotoxy(30, 10);
				cout << "------------------------���߳q��------------------------";
				system("pause");
				break;
			}
		}
		g.print();
		cout << "Player_postion:(" << g.getpost_x() << "," << g.getpost_y() << ")" << endl;
		continue;
	}
}
void gotovxy(int x, int y) 
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = x; scrn.Y = y;
	SetConsoleCursorPosition(hOuput, scrn);

}
void bussinessman() 
{
	while (true)
	{
		system("cls");
		int tb = 0, kb, pb,ex;
		gotovxy(0, 0);
		cout << "==============================";
		gotovxy(0, 8);
		cout << "==============================" << endl;
		gotovxy(0, 1);
		cout <<" �w��Ө�D��ө�!" << endl;
		gotovxy(0, 2);
		cout <<" �Y�n���} �п�J1" <<endl;
		cout <<" �ʶR���~ �п�J2" << endl;
		cout << " �c�檫�~ �п�J3" << endl;
		while (true)
		{
			cin >> ex;
			if (ex<=0||ex>3)
			{
				cout << "��J���~�ЦA��J�@��" << endl;
				continue;
			}
			else break;
		}
		if (ex == 1) 
		{
			system("cls");
			break;
		}
		if (ex == 2) 
		{
			system("cls");
			gotovxy(0, 0);
			cout << "==============================";
			gotovxy(0, 15);
			cout << "==============================" << endl;
			gotovxy(0, 1);
			cout << "��ܨ�����ʶR���~" << endl;
			for (int i = 0; i < b.getgpcount(); i++)
			{
				cout << i + 1 << " " << b.gps[i]->getName() << " ";
			}
			while (true)
			{
				cin >> pb;
				if (pb <= 0 || pb > b.getgpcount())
				{
					cout << "��J���~�ЦA��J�@��" << endl;
					continue;
				}
				else break;
			}
			while (true)
			{
				system("cls");
				gotovxy(0, 0);
				cout << "=========================";
				gotovxy(0, 15);
				cout << "=========================" << endl;
				gotovxy(0, 1);
				cout << "��ܧA�n�ʶR������" << endl;
				cout << "1������ 2���Z�� 3�����ӫ~ 4����^�W�@�B" << endl;
				cout << "��������: " << b.gps[pb - 1]->getmoney() << endl;
				cout << "�I�]�Ѿl�Ŷ�: " << 30 - b.gps[pb - 1]->getitemnum() << endl;
				cin >> kb;
				if (kb <= 0 || kb > 5)
				{
					cout << "�L������ �Э��s��J" << endl;
					continue;
				}
				if (kb == 1)
				{
					cout << "(1): " << kaptr->name << "  ����" << kaptr->cost << endl;
					cout << "(2): " << tuptr->name << "  ����" << tuptr->cost << endl;
					cout << "(3): " << shptr->name << "  ����" << shptr->cost << endl;
					cout << "(4): " << naptr->name << "  ����" << naptr->cost << endl;
					cout << "(5): " << "���ʧO�����~" << endl;
					cout << "�п�ܧA�n�ʶR�����~" << endl;
					cin >> tb;
					if (tb <= 0 || tb > 5)
					{
						cout << "�L������ �Э��s��J" << endl;
						system("cls");
						continue;
					}
					if (tb == 1)
					{
						if (b.gps[pb - 1]->getmoney() >= kaptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - kaptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(kaptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < kaptr->cost || b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 2)
					{
						if (b.gps[pb - 1]->getmoney() >= tuptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - tuptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(tuptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < tuptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 3)
					{
						if (b.gps[pb - 1]->getmoney() >= shptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - shptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(shptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < shptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 4)
					{
						if (b.gps[pb - 1]->getmoney() >= naptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - naptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(naptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < naptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 5)//���Ӥ@��
					{
						break;
					}

				}
				if (kb == 2)
				{
					cout << "(1): " << axptr->name << "  ����" << axptr->cost << endl;
					cout << "(2): " << sgptr->name << "  ����" << sgptr->cost << endl;
					cout << "(3): " << sptr->name << "  ����" << sptr->cost << endl;
					cout << "(4): " << knptr->name << "  ����" << knptr->cost << endl;
					cout << "(5): " << "���ʧO�����~" << endl;
					cout << "�п�ܧA�n�ʶR�����~" << endl;
					cin >> tb;
					if (tb <= 0 || tb > 5)
					{
						cout << "�L������ �Э��s��J" << endl;
						system("cls");
						continue;
					}
					if (tb == 1)
					{
						if (b.gps[pb - 1]->getmoney() >= axptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - axptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(axptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < axptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 2)
					{
						if (b.gps[pb - 1]->getmoney() >= sgptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - sgptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(sgptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < sgptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 3)
					{
						if (b.gps[pb - 1]->getmoney() >= sptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - sptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(sptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < sptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 4)
					{
						if (b.gps[pb - 1]->getmoney() >= knptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - knptr->cost);
							cout << "�ʶR���\!" << endl;
							system("pause");
							b.gps[pb - 1]->putin(knptr);
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < knptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 5)//���Ӥ@��
					{
						break;
					}
				}
				if (kb == 3)
				{
					cout << "(1): " << lifeptr->name << "  ����" << lifeptr->cost << endl;
					cout << "(2): " << magiptr->name << "  ����" << magiptr->cost << endl;
					cout << "(3): " << "���ʧO�����~" << endl;
					cout << "�п�ܧA�n�ʶR�����~" << endl;
					cin >> tb;
					if (tb <= 0 || tb > 5)
					{
						cout << "�L������ �Э��s��J" << endl;
						system("cls");
						continue;
					}
					if (tb == 1)
					{
						if (b.gps[pb - 1]->getmoney() >= lifeptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - lifeptr->cost);
							b.gps[pb - 1]->putin(lifeptr);
							cout << "�ʶR���\!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < lifeptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}

					}
					if (tb == 2)
					{
						if (b.gps[pb - 1]->getmoney() >= magiptr->cost)
						{
							b.gps[pb - 1]->setmoney(b.gps[pb - 1]->getmoney() - magiptr->cost);
							b.gps[pb - 1]->putin(magiptr);
							cout << "�ʶR���\!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getmoney() < magiptr->cost)
						{
							cout << "��������!" << endl;
							system("pause");
							system("cls");
							continue;
						}
						else if (b.gps[pb - 1]->getitemnum() == 29)
						{
							cout << "�Ŷ�����!" << endl;
							system("pause");
							system("cls");
							continue;
						}
					}
					if (tb == 3)
					{
						break;
					}
				}
				if (kb == 4)
				{
					break;
				}
				system("cls");
			}
		}
		if (ex == 3) 
		{
			system("cls");
			gotovxy(0, 0);
			cout << "==============================";
			gotovxy(0, 15);
			cout << "==============================" << endl;
			gotovxy(0, 1);
			cout << "��ܨ���ӳc�檫�~" << endl;
			for (int i = 0; i < b.getgpcount(); i++)
			{
				cout << i + 1 << " " << b.gps[i]->getName() << " ";
			}
			while (true)
			{
				cin >> pb;
				if (pb <= 0 || pb > b.getgpcount())
				{
					cout << "��J���~�ЦA��J�@��" << endl;
					continue;
				}
				else 
				cout << "�������~: " << endl;
				if (b.gps[pb - 1]->getitemnum() == 0)
				{
					cout << "�I�]�O�Ū�" << endl;
					system("pause");
					break;
				}
				b.gps[pb - 1]->showback();
				while (true) 
				{
					cin >> kb;
					if (kb <= 0 || kb > b.gps[pb - 1]->getitemnum())
					{
						cout << "�W�X�d��" << endl;
						continue;
					}
					break;
				}
					b.gps[pb - 1]->setmoney(b.gps[pb - 1]->backpack[kb - 1]->sell + b.gps[pb - 1]->getmoney());
					cout << "��F: " << b.gps[pb - 1]->backpack[kb - 1]->sell << "��" << endl;
					system("pause");
					b.gps[pb - 1]->itemnum--;
					b.gps[pb - 1]->backpack[kb - 1] = NULL;
					break;
			}
		}
		
	}
	
}
