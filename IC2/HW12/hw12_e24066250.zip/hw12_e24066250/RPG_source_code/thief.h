#include<iostream>
#include<math.h>
#include"generalplayer.h"
using namespace std;
#ifndef thief_h
#define thief_h
class thief :public gp
{
public:
	thief();
	thief(int);
	thief(int, string);
	thief(const thief&);
	void setLevel(int);
	void setAttr(int);
	void levelUp(void);
	virtual void skill();
	void increaseExp(int);
};
#endif once
