﻿#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<sstream>
#include<iomanip>
#include<conio.h>
#include"maze.h"
#include"generalplayer.h"
#include<windows.h> 
using namespace std;
void SetColor(int f = 7, int b = 0)
{
	unsigned short ForeColor = f + 16 * b;
	HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hCon, ForeColor);
}

void maze::setmap(string m) 
{
	map.clear();
	mon.clear();
	post_x = 0;
	post_y = 0;
	vector<vector<int>>tempmap;//原圖
	fstream file;
	string line, in;
	file.open(m, ios::in);
	if (!file)
	{
		cout << "Unable to read the file Plz check!!" << endl;
	}
	stringstream ss;//另一個儲存資料的地方
	while (getline(file, line))//抓字串string
	{
		vector <int> temp;
		ss << line;
		string route;
		while (getline(ss, route, ','))//迴避逗號
		{
			stringstream strtoint;
			int num;
			strtoint << route; strtoint >> num;
			temp.push_back(num);
		}
		tempmap.push_back(temp);
		map.push_back(temp);
		ss.str("");
		ss.clear();
	}
	for (int i = 0; i < map.size(); i++)//做出data全為0
	{
		vector<int>temp;
		for (int k = 0; k < map[i].size(); k++)//k=col
		{
			temp.push_back(0);
		}
		data.push_back(temp);
		mon.push_back(temp);
	}
	for (int i = 0; i < map.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < map[i].size(); k++)//k=col
		{
			if (map[i][k] == 200)
			{
				
				data[i][k] = 1;//玩家所在計1
				post_x = k;
				post_y = i;
				map[i][k] = 0;
			}
			else continue;
		}
	}
}

int maze::getpost_x()
{
	return post_x;
}

int maze::getpost_y() 
{
	return post_y;
}

int maze::getdata()
{
	return data[post_y][post_x];
}

int maze::getmondata() 
{
	return mon[post_y][post_x];
}

maze::maze()
{
	mapname = "一始村";
	setmap("新手村.txt");
	//print();
}

void maze::print() //範圍內顯示
{
	for (int i = 1; i < map.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < map[i].size(); k++)//k=colk=x
		{
			if (i == post_y && k == post_x)
			{
				data[i][k] = 1;
				for (int n = -2; n < 3; n++)
				{
					for (int p = -2; p < 3; p++)
					{
						if (n == 0 && p == 0) //玩家位置
						{
							continue;
						}
						if (post_y + n < 1 || post_y + n > map.size() - 1 || post_x + p > map[post_y].size() - 1 || post_x + p < 0)//out of range
						{
							continue;
						}
						else if (0 < post_y + n <= map.size() - 1 && -1 < post_x + p <= map[post_y].size() - 1)//in the range
						{
							if (map[post_y + n][post_x + p] == 0)
							{
								data[post_y + n][post_x + p] = 3;//可行走
							}
							if (map[post_y + n][post_x + p] == 1)
							{
								data[post_y + n][post_x + p] = 4;//障礙物
							}
							if (map[post_y + n][post_x + p] == 300)
							{
								mon[post_y + n][post_x + p] = 5;
								data[post_y + n][post_x + p] = 5;
							}
							if (map[post_y + n][post_x + p] == 400)
							{
								mon[post_y + n][post_x + p] = 8;
								data[post_y + n][post_x + p] = 8;
							}
							if (map[post_y + n][post_x + p] == 600)
							{
								mon[post_y + n][post_x + p] = 6;
								data[post_y + n][post_x + p] = 6;
							}
							if (map[post_y + n][post_x + p] == 1000)
							{
								mon[post_y + n][post_x + p] = 10;
								data[post_y + n][post_x + p] = 10;
							}
							if (map[post_y + n][post_x + p] >=500&& map[post_y + n][post_x + p]<600)
							{
								mon[post_y + n][post_x + p] = 9;
								data[post_y + n][post_x + p] = 9;
							}
						}
					}
				}
				continue;
			}
		}
	}

for (int i = 1; i < map.size(); i++)//玩家的地圖//i=row
{
	for (int k = 0; k < map[i].size(); k++)//k=colk=x
	{
		if (data[i][k] == 1)
		{
			cout << setw(2) << "P";
		}
		else if (data[i][k] == 4)
		{
			SetColor(6, 0);
			cout << setw(2) << "■";
			SetColor(7, 0);
		}
		else if (data[i][k] == 3)
		{
			SetColor(8, 0);
			cout << setw(2) << "□";
			SetColor(7, 0);
		}
		else if (data[i][k] == 5)
		{
			SetColor(8, 0);
			cout << setw(2) << "□";
			SetColor(7, 0);
		}
		else if (data[i][k] == 6)
		{
			SetColor(8, 0);
			cout << setw(2) << "商";
			SetColor(7, 0);
		}
		else if (data[i][k] == 8)
		{
			SetColor(3, 0);
			cout << setw(2) << "長";
			SetColor(7, 0);
		}
		else if (data[i][k] == 9)
		{
			SetColor(4, 0);
			cout << setw(2) << "E";
			SetColor(7, 0);
		}
		else if (data[i][k] == 10)
		{
			SetColor(4, 0);
			cout << setw(2) << "王";
			SetColor(7, 0);
		}
		else
			cout << setw(2) << "";
	}
	cout << endl;
}
	for (int i = 1; i < map.size(); i++)//玩家的地圖//i=row
	{
		for (int k = 0; k < map[i].size(); k++)//k=colk=x
		{
			data[i][k] = 0;//歸0重讀
			if (mon[i][k] == 10)
			{
				continue;
			}
			 if (mon[i][k] == 5)
			 {
				 continue;
			 }
			 if (mon[i][k] == 6)
			 {
				 continue;
			 }if (mon[i][k] == 8)
			 {
				 continue;
			 }
			 if (mon[i][k] == 9)
			 {
				 continue;
			 }
		}
	}
}
