#include<iostream>
#include"item.h"
int item::returnstat() { return 1; }