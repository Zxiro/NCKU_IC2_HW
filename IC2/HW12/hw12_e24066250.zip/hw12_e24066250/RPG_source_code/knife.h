#include<iostream>
#include"weapon.h"
using namespace std;
#ifndef knife_h
#define knife_h
class knife :public weapon
{
public:
	knife();
};
#endif
