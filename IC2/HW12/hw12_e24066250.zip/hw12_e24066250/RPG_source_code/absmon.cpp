#include<iostream>
#include<string>
#include"absmon.h"
#include<random>
#include<time.h>
#include<fstream>
#include"generalplayer.h"
#include"item.h"
#include<sstream>
using namespace std;
int absmon ::count = 0;
void absmon::sethp(int a)
{
	hp = a;
}
int absmon::gethp()const 
{
	return hp;
}
void absmon::setmp(int a)
{
	mp = a;
}

int absmon::getmp()const
{
	return mp;
}
int absmon::getdef()const 
{
	return defense;
}
void absmon::attackto(gp*p) 
{
}
absmon::absmon(string s, int a, int b, int c, int d, int e,int m)
	:name(s), attack(a), defense(b), exp(c), max_hp(d), max_mp(e),money(m)
{
	item*ite;
	count++;
}
absmon::~absmon()//�Ǫ����`
{
	count--; 
}
void absmon::attr() //��o��T
{
	cout << "NAME: " << name << endl << endl << "HP: " << hp << endl << endl << "MP: " << mp << endl << endl << "DEF: " << defense << endl << endl << "ATT: " << attack << endl << endl << "EXP:" << exp << endl;
}
string absmon::serial()const
{
	string t;
	string data = "PD:";
	stringstream s;
	s << gethp();
	s >> t;
	data = data + t + ",";
	s.str("");
	s.clear();
	t.clear();
	cout << gethp() << endl;
	s << getmp();
	s >> t;
	data = data + t + ",";
	s.str("");
	s.clear();
	t.clear();
	cout << getmp() << endl;
	string file = "filedata.txt";
	fstream f;
	f.open(file, ios::out);
	f << data;
	f.close();
	return data;
}
void absmon::unserial()
{
	fstream file;
	string filename = { "filedata.txt" };
	file.open(filename, ios::in);

	char abc;

	file >> name >> abc >> abc >> hp >> abc >> mp;




	file.close();
}