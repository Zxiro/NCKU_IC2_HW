#include<iostream>
#include"absmon.h"
#include"weapon.h"
#include<string>
using namespace std; 
#ifndef spikeglove_h
#define spikeglove_h
class spikeglove:public weapon
{public:
	spikeglove();
};
#endif
