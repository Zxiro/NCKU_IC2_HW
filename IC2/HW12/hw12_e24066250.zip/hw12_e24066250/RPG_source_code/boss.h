#include<iostream>
#include<string>
#include<random>
#include"generalplayer.h"
#include"absmon.h"
#include"item.h"
using namespace std;
#ifndef boss_h
#define boss_h
class boss :public absmon
{
public:
      boss();
	  ~boss();
	  virtual void attackto(gp*);
};
#endif

