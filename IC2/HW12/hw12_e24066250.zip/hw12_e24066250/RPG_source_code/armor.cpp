#include<iostream>
#include"armor.h"
using namespace std;
armor::armor(int def) 
{
	defense_increment=def;
}int armor::returnstat()
{
	return defense_increment;
}