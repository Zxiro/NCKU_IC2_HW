#include<iostream>
#include"weapon.h"
using namespace std;
weapon::weapon(int att)
	:attack_increment(att)
{}
int weapon::returnstat() 
{
	return attack_increment;
}