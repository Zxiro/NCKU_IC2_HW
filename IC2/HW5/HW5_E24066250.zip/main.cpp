﻿/*Double Version*/
#include<iostream>
#include"Matrix.h"
using namespace std;
Matrix m;
void Matrix::setup(int r, int c)
{
	row = r; col = c;
	//cout << "row" << row << endl; cout << "col" << col << endl;
	setupm = new double *[r];
	//此矩陣有 r 個列(rows); 先 new 出 r個 int *
	for (int i = 0; i<r; i++)
	{
		setupm[i] = new double[c];
		//每一列有 c 行(columns); setupm[i] 指向新 new 出的 c 個 int
	}
	for (int i = 0; i < r; i++) 
	{
		for (int k = 0; k < c; k++) 
		{
			setupm[i][k] = 0;
		}
	}
	/*for (int i = 0; i<r; i++)
	{
		delete[] setupm[i];
	}
	delete[] setupm;*/
}
Matrix::Matrix() 
{
	setup(2, 2);
}
Matrix::Matrix(int r, int c)
{
	setup(r, c);
}
Matrix::Matrix(int r, int c, double a[], int rc)
{
	setup(r, c);
	rc = r * c;
	int k = 0;
	for (int z = 0; z < r; z++)
	{
		for (int y = 0; y < c; y++)
		{
			setupm[z][y] = a[k];
			k++;
		}
	}
}
Matrix::Matrix(const Matrix &m) 
{
	setup(m.row, m.col);
	for (int i = 0; i <m.row; i++)
	{
		for (int k = 0; k <m. col; k++)
		{
			setupm[i][k] = m.setupm[i][k];
		}
	}
}
Matrix::~Matrix() 
{ for(int i = 0; i<row; i++)
    {
		delete[] setupm[i];
	}
		delete[] setupm;
}
void Matrix::setData(int r, int c, double i) 
{
	setupm[r][c] = i;
}
double Matrix::getData(int r, int c)const 
{
	return setupm[r][c];
}
int Matrix::getRow() const 
{
	int r;
	r = row;
	return r;
}
int Matrix::getCol() const
{
	int c;
	c = col;
	return c;
}
Matrix Matrix::transpose() 
{
	Matrix m(col, row);//設置一個全是0的轉至矩陣
	for (int i = 0; i < m.row; i++) 
	{
		for (int k = 0; k <m. col; k++) 
		{
			m.setupm[i][k] =setupm[k][i];
		}
	}
	return m;
}
Matrix Matrix::add(const Matrix & m)
{
	Matrix a(row,col); 
	for (int i = 0; i < row; i++) 
	{
		for (int k = 0; k < col; k++) 
		{
			a.setupm[i][k] = (m.setupm[i][k] + setupm[i][k]);
		}
	}
	return a;
}
Matrix Matrix::multiply(const Matrix & m) 
{
	Matrix a(row, m.col);
	double z = 0;
	for (int i = 0; i < row; i++) //原本的row
	{
		for (int j = 0; j < m.col; j++) //相乘的col
		{
			for (int k = 0; k < col; k++)//原本的col
			{
				z = z + setupm[i][k] * m.setupm[k][j];
			}
			a.setupm[i][j]=z;
			z = 0;
		}
	}
return a;
}
int main()
{
	cout << "<<Default Construster>>\ntest1\n";
	Matrix test1;
	test1.displayData();
	cout << endl;
	
	cout << "\n<<Constructor>> (只設定大小, 資料預設為0)" << endl;
	cout << "test2\n";
	Matrix test2(3, 4);
	test2.displayData();
	cout << endl;

	cout << "\n<<Constructor>>\ntest3a\n";
	double m2[6] = { 0,1,4,-7.2,8.1,2.6 };
	Matrix test3a(3, 2, m2, 6);
	test3a.displayData();
	cout << endl;
	
	cout << "test3b\n"; //for multiply
	double m1[6] = { 2.2,-1,6,4.3,8,-8.1 };
	Matrix test3b(2, 3, m1, 6);
	test3b.displayData();
	cout << endl;

	cout << "\n<<Copy constructor>>\ntest4\n";
	Matrix test4(test3a);
	test4.displayData();
	cout << endl;

	cout << "\n<<Set data>>\ntest4\n";
	test4.setData(0, 1,7.2);
	test4.displayData();
	cout << endl;
	
	cout << "\ntest4(0,1)=";//Get data
	cout << test4.getData(0, 1);
	cout << endl;

	cout << "\ntest4(row,col)=" << "(" << test4.getRow() << "," << test4.getCol() << ")" << endl;
	cout << endl;

	cout << "\n<<Transpose>>\n";
	test4.displayData();
	cout << "transpose\n";
	test4.transpose().displayData();
	cout << endl;

	cout << "\n\n<<Add>>" << endl;
	cout << "test3a + test4:" << endl;
	test3a.displayData();
	cout << " +\n";
	test4.displayData();
	cout << " =" << endl;
	test3a.add(test4).displayData();
	cout << endl;

	cout << "\n<<Mmultiply>>" << endl;
	cout << "test3a * test3b" << endl;
	test3a.displayData();
	cout << " *\n";
	test3b.displayData();
	cout << " =" << endl;
	test3a.multiply(test3b).displayData();
	cout << endl;
	system("pause");
	return 0;
}

