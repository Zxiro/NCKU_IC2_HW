#include<iostream>
#include<string>
#include"absmon.h"
#include<random>
#include<time.h>
using namespace std;
int absmon ::count = 0;
void absmon::sethp(int a)
{
	hp = a;
}
int absmon::gethp()const 
{
	return hp;
}
void absmon::setmp(int a)
{
	mp = a;
}
int absmon::getmp()const
{
	return mp;
}
int absmon::getdef()const 
{
	return defense;
}
void attackto(gp*p) 
{
}
absmon::absmon(string s, int a, int b, int c, int d, int e)
	:name(s), attack(a), defense(b), exp(c), max_hp(d), max_mp(e) 
{
	count++;
}
absmon::~absmon()//�Ǫ����`
{
	count--; 
}
void absmon::attr() //��o��T
{
	cout << "NAME: " << name << endl << endl << "HP: " << hp << endl << endl << "MP: " << mp << endl << endl << "DEF: " << defense << endl << endl << "ATT: " << attack << endl << endl << "EXP:" << exp << endl;
}