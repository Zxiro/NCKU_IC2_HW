#include<iostream>
#include<string>
#include<random>
#include<time.h>
#include"absmon.h"
#include"zombie.h"
#include"boss.h"
#include"goblin.h"
#include"magi.h"
#include"knight.h"
#include"orc.h"
#include"generalplayer.h"
using namespace std;
int main(void) 
{
	knight k(3,"NEW ");
	gp*kptr = &k;
	goblin g;
	absmon*gptr = &g;
	boss b;
	zombie z;
	while(true)
	{
		g.attr();
		b.attr();
		z.attr();
		system("pause");
		system("cls");
	}
	
}