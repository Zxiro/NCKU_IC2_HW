#include<iostream>
#include<math.h>
#include"generalplayer.h"
using namespace std;
#ifndef orc_h
#define orc_h
class orc :public gp
{
public:
	orc();
	orc(int);
	orc(int, string);
	orc(const orc&);
	void setLevel(int);
	void setAttr(int);
	void levelUp(void);
	void increaseExp(int);
	virtual void skill()=0;
};
#endif
