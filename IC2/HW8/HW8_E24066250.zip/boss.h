#include<iostream>
#include<string>
#include"generalplayer.h"
#include"absmon.h"
using namespace std;
#ifndef boss_h
#define boss_h
class boss :public absmon
{
public:
      boss();
	  ~boss();
	  virtual void attackto(gp*);
};
#endif

