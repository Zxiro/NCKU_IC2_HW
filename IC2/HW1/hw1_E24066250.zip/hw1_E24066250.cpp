#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include <algorithm>
using namespace std;

int main(void) 
{
	fstream file;
	string line;
	vector<vector<int>>test;
	vector<int>temp;
	int tempn=0,finalans;
	file.open("input.txt", ios::in);
	if (!file)
	{
		cout<< "Fail to open file, Plz try it again" << endl;
	}
	else
		finalans = file.get();
	    temp.push_back(finalans-'0');
		char d;
		d = file.get();
		while (getline(file, line, '\n'))
		{
			for (int i = 0; i <= line.length(); i++) 
			{
				if (isdigit(line[i])) 
				{
					if (line[i] == 'nn')
					{
						continue;
					}
					else if (isdigit(line[i + 1]))
					{
						int k = 1;
						while (isdigit(line[i + k]))
						{
							if (tempn!=0)
							{
								tempn = tempn * 10 + (line[i + k] - '0');
								line[i + k] = 'nn';
								goto kk;
							}
							tempn = (line[i] - '0') * 10 + (line[i + k] - '0');
							line[i + k] = 'nn';
						kk:	k++;
						}
						temp.push_back(tempn);
						tempn = 0;
					}
					 else if (line[i + 1] == ' ' || isdigit(line[i+1])==0)
					{
						temp.push_back(line[i] - '0');						
					}
					else if (i - 1 < 0) 
					{
						continue;
					}
				}
			}
		}
	cout << endl << endl << endl << endl << endl << endl;
	for (int i = 1; i < temp.size(); i+=2) 
	{
		vector<int>tem;
		tem.push_back(temp[i]);
		if (i + 1 == temp.size()) 
		{
			break;
		}
		tem.push_back(temp[i+1]);
		test.push_back(tem);
	}

	for (int i = 0; i < test.size(); i++) 
	{
		for (int k = 0; k < test[i].size(); k++)
		{
			cout<<"  " << test[i][k]; //I row(����) K(��o)
		}
		cout << endl;
	}
	int co=-1,column,ansc=0,max=0,yy;
	for (int z = 0; z < finalans - '0'; z++)//���X�|town
	{
		if (z == 0)
		{
			yy = 0;//town�����@
			co = test[0][1];//�o��town���X��
			ansc = co + 1;
		}
		else if (z != 0)
		{
		    yy = ansc;//town�����@��
			co = test[yy][1];//�o��town���X��
			ansc = yy + co + 1;
		}
		while (true)
		{
			//int vc = 0;
			vector<int>vcc;
			for (int t = 1; t < co; t++)
			{
				int c = 0;
				//cout << test[yy + t][c] << "�ϩR" << endl;
				if (test[yy + t][c] != 0)
				{
					vcc.push_back(test[yy + t][c]);
					vcc.push_back(test[yy + t][c + 1]);
					column = yy + t;
					/*for (int y = 0; y < vcc.size(); y++)
					{
						cout << vcc[y] << "m" << endl;
					}*/
					test[yy + t][c] = 0;
					test[yy + t][c + 1] = 0;
					break;
				}
				else if (test[yy + t][c] == 0)
				{
					continue;
				}
				cout << endl;
			//	break;
			}
			for (int t = 1; t <co; t++)//yy+1 town���U���@�� t�O�n���U�� 
			{
				for (int vc = 0; vc < vcc.size(); vc++)
				{
					
					if (test[yy + 1 + t][0] == vcc[vc] || test[yy + 1 + t][1] == vcc[vc])//�䤤�@�Ӭ۵�
					{
							if (test[yy + 1 + t][0] != vcc[vc])
							{
								vcc.push_back(test[yy + 1 + t][0]);
								test[yy + 1 + t][0] = 0;
								test[yy + 1 + t][1] = 0;
								//cout << "k1" << endl;
							}
							else if (test[yy + 1 + t][1] != vcc[vc] )
							{
								vcc.push_back(test[yy + 1 + t][1]);
								test[yy + 1 + t][0] = 0;
								test[yy + 1 + t][1] = 0;
							//	cout << "k2" << endl;
							}
					}
					else
					{
						continue;
					}
				}
				sort(vcc.begin(), vcc.end());  //�Ƨ�
				vcc.erase(unique(vcc.begin(), vcc.end()), vcc.end());
			}
			if (vcc.size() > max)
			{
				max = vcc.size();

				if (vcc.size() > test[yy][0] / 2)
				{
					cout << "�̦h�զX��" << max << "�H" << endl;
					max = 0;
					break;
				}
				else if (test[yy+co - 1][0] == 0 && test[yy+co- 1][1] == 0)
				{
					cout << "�̦h�զX��" << max << "�H" << endl;
					max = 0;
					break;
				}
			}
			
		}
	}
	cout<<"�ռ�"<< finalans - '0' << endl;
	system("pause");

}